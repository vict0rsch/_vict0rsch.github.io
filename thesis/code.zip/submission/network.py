import utils
import numpy as np
import tensorflow as tf
from importlib import reload
from tensorflow.contrib.layers import xavier_initializer, fully_connected

np.random.seed(2)
tf.set_random_seed(2)


class Network(object):

    def __init__(self, hyper_parameters, name=None):
        """
        Abstract class from which the Question and Action Networks inherit
        """
        self.emb_vocab = None
        self.emb_matrix = None
        self.name = name
        self.hp = hyper_parameters
        self.dense_layers = self.hp.dense_layers

        self.current_observation_output = None
        self.next_observation_output = None

        self.dropout_ph = tf.placeholder(
            tf.float32, name='dropout_ph')

    def get_target_output(self, input_tensor):
        """
            Returns the tf variable representing the Q value
            from the Target Network
        """
        return tf.stop_gradient(
            utils.fixed_linear_with_logits(
                input_tensor,
                self.hp.dense_layers,
                self.name
            )
        )

    def set_embedding_variable(self, vocab, matrix):
        """
            creates attributes emb_vocab, emb_matrix and the tensor (for lookup)
            emb_matrix_tensor
        """
        self.emb_vocab = vocab
        self.emb_matrix = matrix
        self.emb_matrix_tensor_no_oov = tf.get_variable(name=self.name + "embedding_tensor",
                                                        shape=matrix.shape,
                                                        initializer=tf.constant_initializer(
                                                            matrix),
                                                        trainable=False)
        self.embedding_size = matrix.shape[1]
        self.oov_tensor = self.get_oov_variable()
        self.emb_matrix_tensor = tf.concat(
            (self.oov_tensor, self.emb_matrix_tensor_no_oov), axis=0)

    def embed_tensor(self, tensor):
        """
            looksup a tensor in the embedding matrix attribute self.emb_matrix_tensor
        """
        return tf.nn.embedding_lookup(
            self.emb_matrix_tensor, tensor)

    def get_dense_output(self, input_tensor, reuse, scope):
        """
            Creates the representation of input_tensor through the network.
            reuse and scope specify if an existing network defined in a scope should
            be reused or if it should create a new one in this scope
        """
        scope = scope or self.name + 'DenseOutput'
        with tf.variable_scope(scope, reuse=reuse):
            local_tensor = input_tensor
            xav = xavier_initializer()
            for i, l in enumerate(self.dense_layers[:-1]):
                local_tensor = fully_connected(local_tensor,
                                               l,
                                               biases_initializer=xav,
                                               reuse=reuse,
                                               scope='fully_connected_' + str(
                                                   i) if scope is not None else None,
                                               activation_fn=utils.selu
                                               )
            i += 1
            last = fully_connected(local_tensor,
                                   self.dense_layers[-1],
                                   activation_fn=None,
                                   biases_initializer=xav,
                                   reuse=reuse,
                                   scope='fully_connected_' + str(
                                       i) if scope is not None else None
                                   )
        return last

    def get_oov_variable(self):
        """
            returns a tf variable representing the OOV vector
        """
        return tf.get_variable(self.name + "OOVTensor",
                               shape=[
                                   1,
                                   self.embedding_size
                               ],
                               initializer=tf.random_normal_initializer,
                               trainable=True)

    def phs(self):
        """
            returns a list of the placeholders needed in general by the network
        """
        return [p for p in dir(self) if '_ph' in p]

    def set_output_tensors(self):
        raise Exception("`set_output_tensors` is not implemented")


class Question_Network(Network):
    """
        Child class of Network describing the agent's Question network
    """

    def __init__(self, hyper_parameters):
        """
            question_ph : batch * max_question_length

            question_word_count_ph : batch (with values length of each
                question in the batch)
        """
        super().__init__(hyper_parameters, 'QN')
        self.question_ph = tf.placeholder(
            tf.int32, [None, None], "current_question_ph")
        self.question_word_count_ph = tf.placeholder(
            tf.float32, [None], 'question_word_count')

    def represent_3D_question(self, question_3D_tensor):
        """
            For now simply a mean of the word embeddings in the question

            question_3D_tensor : batch * max_question_length * embedding_size
                                    -> batch * embedding_size
            question_word_count_ph is needed so as to compute a true mean
                and disregard the paddings (which have embedding 0)
        """
        with tf.variable_scope('Represent3DQuestion'):
            with tf.variable_scope('MeanRepresentation'):
                mean_embeddings = tf.divide(
                    tf.reduce_sum(question_3D_tensor, axis=1),
                    tf.stack([self.question_word_count_ph] * self.embedding_size,
                             axis=1))
            with tf.variable_scope('MaxRepresentation'):
                l2_embeddings = tf.norm(question_3D_tensor, axis=2)
                max_locations = tf.cast(
                    tf.argmax(l2_embeddings, axis=1), tf.int32)
                range_tensor = tf.range(tf.shape(max_locations)[0])
                indexes = tf.stack([range_tensor, max_locations], axis=1)
                max_embeddings = tf.gather_nd(question_3D_tensor, indexes)
            with tf.variable_scope('ConcatMeanMax'):
                representation_2D = tf.concat(
                    [mean_embeddings, max_embeddings], axis=1)

        return representation_2D

    def set_output_tensors(self):
        """
            1) embed the questions
                batch * max_question_length
                    -> batch * max_question_length * embedding_size

            2) collapse word embeddings
                batch * max_question_length * embedding_size
                    -> batch * embedding_size

            3) forward through dense network :
                batch * embedding_size
                    -> batch * dense_output_size
        """
        embedded_question = self.embed_tensor(self.question_ph)
        merged_question = self.represent_3D_question(
            embedded_question)

        self.question = self.get_dense_output(
            merged_question, False, None)
        self.target_question = self.get_target_output(merged_question)


class Action_Network(Network):

    def __init__(self, hyper_parameters):
        """
            current_action_ph : batch * max_action_length -> represents the action that was
                taken at time step t

            next_actions_ph : batch * max_action_nb * max_action_length -> represents all
                the possible actions to take at time step t + 1. Currently exactly set to
                self.hp.number_of_actions, with repeating actions if not enough to split the
                tensor along the second axis

            action_word_count_ph : batch * max_action_nb (with values length of each action in each batch)
        """
        super().__init__(hyper_parameters, 'AN')
        self.next_actions_ph = tf.placeholder(
            tf.int32, [None, None, None], "next_actions_ph")
        self.next_actions_word_count_ph = tf.placeholder(
            tf.float32, [None, None], 'next_actions_word_count_ph')
        self.next_actions_submit_score_ph = tf.placeholder(
            tf.float32, [None, None], 'next_actions_submit_score_ph')
        self.next_actions_query_score_ph = tf.placeholder(
            tf.float32, [None, None], 'next_actions_query_score_ph')
        self.current_action_submit_ph = tf.placeholder(
            tf.float32, [None], 'current_action_submit_ph')
        self.current_action_ph = tf.placeholder(
            tf.int32, [None, None], "current_action_ph")
        self.current_action_word_count_ph = tf.placeholder(
            tf.float32, [None], 'current_action_word_count_ph')
        self.current_action_submit_score_ph = tf.placeholder(
            tf.float32, [None], 'current_action_submit_score_ph')
        self.current_action_query_score_ph = tf.placeholder(
            tf.float32, [None], 'current_action_query_score_ph')

    def get_actions_for_next_state(self):
        """
            Goal here is to get a representation of each action for each batch sample so as
            to get the max of the q value accross these

            1) embed each action
                batch * max_action_nb * max_action_length
                    -> batch * max_action_nb * max_action_length * embedding_size

            2) collapse actions' word embeddings
                batch * max_action_nb * max_action_length * embedding_size
                    -> batch * max_action_nb * embedding_size

            3) forward through dense network
                batch * max_action_nb * embedding_size
                    -> batch * max_action_nb * dense_output_size

        """
        with tf.variable_scope('NSActions'):
            # batch_size x max_action_nb * max_action_length x embedding_size]
            embedded_actions = tf.nn.embedding_lookup(
                self.emb_matrix_tensor, self.next_actions_ph)

            # batch_size * max_action_nb * embedding_size
            merged_actions = self.represent_4D_actions(
                embedded_actions)

        dense_actions = self.get_target_output(merged_actions)

        return dense_actions

    def get_action_for_current_state(self):
        """
            For timestep t we want to know the action-value predicted for
            each action taken in the batch :

            1) embed each action 
                batch * max_action_length
                    -> batch * max_action_length * embedding_size

            2) collapse embeddings
                batch * max_action_length * embedding_size
                    ->  batch * embedding_size

            3) forward through dense network
                batch * embedding_size
                    -> batch * dense_output_size

            4) add dim to compute inner product with question representation
                batch * dense_output_size
                    -> batch * max_action_nb = 1 * dense_output_size
        """
        with tf.variable_scope('CSActions'):
            embedded_action = tf.nn.embedding_lookup(
                self.emb_matrix_tensor, self.current_action_ph)
            merged_action = self.represent_3D_action(embedded_action)

        dense_action_output = self.get_dense_output(
            merged_action, False, None)

        return dense_action_output

    def represent_3D_action(self, action_3D_tensor):
        """
            Collapses word embeddings within a sentence.
            action_3D_tensor : batch * max_action_length * embedding size
                                -> batch * embedding_size
        """
        with tf.variable_scope('Represent3DAction'):

            with tf.variable_scope('MeanRepresentation'):
                mean_embeddings = tf.divide(
                    tf.cast(tf.reduce_sum(action_3D_tensor, axis=1), tf.float32),
                    tf.cast(tf.stack([self.current_action_word_count_ph] * self.embedding_size,
                                     axis=1), tf.float32)
                )
            with tf.variable_scope('MaxRepresenation'):
                l2_embeddings = tf.norm(action_3D_tensor, axis=2)
                max_locations = tf.cast(
                    tf.argmax(l2_embeddings, axis=1), tf.int32)
                range_tensor = tf.range(tf.shape(max_locations)[0])
                indexes = tf.stack([range_tensor, max_locations], axis=1)
                max_embeddings = tf.gather_nd(action_3D_tensor, indexes)
            with tf.variable_scope('ConcatMeanMax'):
                representation_2D = tf.concat(
                    [mean_embeddings, max_embeddings], axis=1)
                self.repr = representation_2D

        return representation_2D

    def represent_4D_actions(self, action_4D_tensor):
        """
            Collapses word embeddings within a sentence.
            action_4D_tensor : batch * max_action_nb * max_action_length * embedding_size
                                -> batch * max_action_nb * embedding_size
        """
        with tf.variable_scope('Represent4DActions'):
            with tf.variable_scope('MeanRepresentation'):
                summed_actions = tf.reduce_sum(action_4D_tensor, axis=2)
                repeated_action_word_count = tf.stack([self.next_actions_word_count_ph] * self.embedding_size,
                                                      axis=2)
                mean_embeddings = tf.divide(
                    summed_actions, repeated_action_word_count)
            with tf.variable_scope('MaxRepresentation'):
                l2_embeddings = tf.norm(action_4D_tensor, axis=3)
                max_locations = tf.cast(
                    tf.argmax(l2_embeddings, axis=2), tf.int32)
                one_hot_location = tf.expand_dims(
                    tf.one_hot(
                        max_locations, tf.shape(action_4D_tensor)[2], on_value=1.0, off_value=0.0
                    ), axis=3
                )

                max_mask = tf.tile(one_hot_location, [
                                   1, 1, 1, self.embedding_size])
                max_embeddings = tf.reduce_sum(
                    tf.multiply(action_4D_tensor, max_mask),
                    axis=2
                )
                self.max_embeddings = max_embeddings
            with tf.variable_scope('ConcatMeanMax'):
                represenation_3D = tf.concat(
                    [mean_embeddings, max_embeddings], axis=2)
        return represenation_3D

    def set_output_tensors(self):
        # next_state uses target network
        self.actions_for_next_state = self.get_actions_for_next_state()
        self.action_for_current_state = self.get_action_for_current_state()
