import data_structures as ds
from time import time
from numpy.random import permutation
from importlib import reload
import numpy as np

reload(ds)

if __name__ == '__main__':
    """
        File running comparisons between memory buffer implemetations
    """
    init_size = 10000
    exp_nm = 100
    max_size = 11000
    multiple_add = 3000

    mbs = []
    mba = []
    ss = []
    sa = []
    mmbat = []
    msat = []

    original_store = {
        'current_action': [],
        'current_action_wc': [],
        'current_action_submit_score': [],
        'current_action_query_score': [],
        'current_action_submit': [],
        'next_actions': [],
        'next_actions_wc': [],
        'next_actions_query_score': [],
        'next_actions_submit_score': [],
        'question': [],
        'question_wc': [],
        'reward': [],
        'not_over': [],
        'length': 0,
        'title': []
    }
    for i in range(init_size):
        for k in original_store:
            if k != 'length':
                original_store[k].append('blabla blabla bla')

    keys = {k for k in original_store if k != 'length'}

    for _ in range(exp_nm):
        print('\r%d' % _, end='')

        mb = ds.MemoryBuffer(max_size=init_size)

        store = original_store.copy()

        mb.add(store)

        mb_sample_time = time()
        _ = mb.sample(256)
        mbs.append(time() - mb_sample_time)

        store_sample_time = time()
        perm = permutation(init_size)[:256]
        batch_store = {
            k: [store[k][i] for i in perm]
            for k in keys
        }
        ss.append(time() - store_sample_time)

        temp_store = {}
        for k in keys:
            temp_store[k] = ['blabla blabla bla']
        
        multiple_mb_add_time = time()
        for l in range(multiple_add):
            mb_add_time = time()
            mb.add(temp_store)
            mba.append(time() - mb_add_time)
        mmbat.append(time() - multiple_mb_add_time)

        multiple_store_add_time = time()
        for l in range(multiple_add):
            store_add_time = time()
            for k in keys:
                store[k] += temp_store[k]
            sa.append(time() - store_add_time)
            if len(store['current_action']) > max_size:
                    for k in keys:
                        del store[k][0]
        msat.append(time() - multiple_store_add_time)


    print('mba', np.mean(mba))
    print('sa', np.mean(sa))
    print('mbs', np.mean(mbs))
    print('ss', np.mean(ss))
    print('mmbat', np.mean(mmbat))
    print('msat', np.mean(msat))
    print()

    print('Sample mbs/ss', np.mean(mbs)/ np.mean(ss))
    print('Unique Add: mba/sa', np.mean(mba) / np.mean(sa))
    print('Multiple Add mmbat/msat', np.mean(mmbat)/ np.mean(msat))