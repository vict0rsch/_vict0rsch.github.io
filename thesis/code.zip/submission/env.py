import os
import sys
import pdb
import copy
import json
import spacy
import shutil
import operator
import numpy as np
import pickle as pkl
import utils as utils
from time import time
import tensorflow as tf
from whoosh import index
sys.path.append('~/jtr/')
from importlib import reload
import hyperparameter as hyp
sys.path.append('../../jtr/')
import jtr.readers as readers
from jtr.core import SharedResources
from numpy.random import permutation
from multiprocessing.dummy import Pool
from whoosh.qparser import QueryParser
from jtr.data_structures import convert2qasettings

reload(hyp)
reload(utils)
np.random.seed(2)
tf.set_random_seed(2)


class Environment(object):

    # @utils.time_('Env creation')
    def __init__(self, hyperparams=None, searcher=None, models=None):
        """
            Environment's class. Main methods are reset() and step()

            Args:
                hyperparams: optional hyper parameters to use
                searcher: optional pre-loaded Searcher instance
                models: optional pre-loaded list of Jack instances
        """
        hyperparams = hyperparams or hyp.HyperParameter('env')
        self.hp = hyperparams
        self.data_source = hyperparams.data_source
        self.model_paths = hyperparams.model_paths
        self.whoosh_path = hyperparams.whoosh_path
        self.model_nb = len(self.model_paths)
        self.beam_sizes = [hyperparams.beam_size] * self.model_nb
        self.multi = hyperparams.multi
        self.n_multi = hyperparams.n_multi
        self.known_uuids = set()
        self.known_episode_uuids = set()
        self.max_steps_per_episode = hyperparams.max_steps_per_episode
        self.model_names = [
            m.split('/')[-2] if m[-1] == '/' else m.split('/')[-1] for m in self.model_paths]
        self.categories = ["instance of", "sex or gender", "country", "date of birth", "sport",
                           "color", "chromosome", "melting point", "conferred by"]

        self.model_types = ['fastqa_reader'] * self.model_nb

        self.is_state_terminal = True
        print('Loading Searcher...')
        if searcher is not None:
            self.searcher = searcher
        else:
            if self.multi:
                self.searcher = MultiSearcher(
                    self.whoosh_path, self.data_source)
            else:
                self.searcher = Searcher(self.whoosh_path, self.data_source)

        print('Loading model...')
        # self.models is a list of Jack instances used for inference and state
        # values
        self.models = models or [Jack(self.model_paths[m], model_type=self.model_types[m],
                                      beam_size=self.beam_sizes[m]) for m in range(self.model_nb)]

        # print('Setting uuids...')
        with open(self.whoosh_path + 'uuid_dataset.pkl', 'rb') as f:
            tmp = pkl.load(f)
            self.uuids = []
            for c in self.categories:
                self.uuids += tmp[self.data_source][c]

        self.uuids = np.array(self.uuids)
        self.size = len(self.uuids)
        if self.multi:
            self.full_uuids = self.uuids
            self.uuids = [self.uuids[i * len(self.uuids) // self.n_multi:
                                     (i + 1) * len(self.uuids) // self.n_multi]
                          for i in range(self.n_multi)]
        self.searcher.uuids = self.uuids

        self.search_time = []
        self.infer_time = []
        self.state_time = []
        self.step_time = []

        self.nlp = spacy.en.English()

    def sample_uuids(self, n):
        """
            Samples n uuids from the whoosh-indexed DB (uniformly)

            n: int, number of uuids to sample
            returns:  list of uuids
        """
        perm = permutation(self.size)[:n]
        if self.multi:
            return self.full_uuids[perm]
        return self.uuids[perm]

    @utils.time_()
    def test_models(self, uuids=None, n=50, verbose=0, file_name=None):
        """
            Tests the Env's models

            Args:
                uuids: optional list of uuids to query
                n: optional number of instances to test the models on
                verbose: optional int,  >0 prints, >1 prins and drops a file
                file_name: file to be droped if verbose > 1

            Returns:
                tuple (proposals, answers, questions) as lists
        """
        uuids = uuids or self.sample_uuids(n)
        n = len(uuids)
        uuids_, questions_, answers_, answer_locations_, texts_ = self.searcher.get_qa_data(
            uuids)
        short_texts = []
        for t in texts_:
            t_list = t.split(' ')
            if len(t_list) > 1000:
                t = ' '.join(t_list[:1000])
            short_texts.append(t)
        texts_ = short_texts

        jtr_data = utils.to_jtr_format(
            uuids_, questions_, answers_, answer_locations_, texts_)

        try:
            proposals = []
            _ = time()
            for m in range(self.model_nb):
                prop, answers, questions = self.models[m].infer_with_labels(
                    jtr_data)
                proposals.append(prop)
            self.infer_time.append(time() - _)
        except:
            return ((uuids_, questions_, answers_, answer_locations_, texts_), 0, 0)

        if verbose > 0:
            s = ''
            for i in range(n):
                s += '\n'
                s += questions[i].question + '\n'
                s += 'True answer : ' + \
                    answers[i][0].text + '  span : ' + \
                    str(answers[i][0].span) + '\n'
                for m in range(self.model_nb):
                    s += self.model_names[m] + ' 5 most likely:\n'
                    for bs in range(5):
                        prop = proposals[m][i][bs]
                        s += '    ' + str(prop.score) + \
                             ' ' + prop.text + '\n'
                if verbose > 1:
                    file_name = file_name or 'env_test' + \
                        str(len([os.listdir('../prints/')])) + '.txt'
                    with open('../prints/' + file_name, 'w') as f:
                        print(s, file=f)
            print(s)

        return proposals, answers, questions

    # @utils.time_()
    def reset(self, verbose=0, uuid_generator=None):
        """
            Resets the Environment for a new episode

            Args:
                verbose: optional int to print the Env's reset state 
                uuid_generator: generator to get the next uuid from. If None, 
                    a uuid is sampled from non-know ones
            
            Returns:
                state and start_title
        """

        self.current_step = 0
        self.is_state_terminal = False
        self.previous_value_for_reward = 0
        self.known_episode_uuids = set()

        if uuid_generator is None:
            loop = True
            while loop:
                self.start_uuid = self.sample_uuids(1)[0]
                self.current_uuid = self.start_uuid

                self.start_query = self.searcher.search_uuid(self.start_uuid)[
                    0]
                if len(self.start_query['answer_string_sequence']) > 0 and (
                    self.start_uuid not in self.known_uuids
                ):
                    loop = False
                    self.known_uuids.add(self.start_uuid)
        else:
            uuid = next(uuid_generator)
            self.start_uuid = uuid
            self.current_uuid = self.start_uuid
            self.start_query = self.searcher.search_uuid(self.start_uuid)[0]
        self.current_query = self.start_query
        self.known_episode_uuids.add(self.start_uuid)

        if 'born ?' in self.start_query['question']:
            self.start_query['question'] = utils.add_space(
                self.start_query['question'], 'born ?')

        self.current_context = self.start_query['string_sequence']

        self.start_title = self.start_query['title']
        self.current_title = self.start_title
        self.question = self.start_query['question']
        self.answer = self.start_query['answer_string_sequence']

        state = self.state()

        if verbose > 0:
            print('Question : ', self.question)
            print('Answer : ', self.answer)
            print('Current Article title : ', self.current_query['title'])
            print('State : ', state)
        return state, self.start_title

    def state(self):
        """
            potential actions and scores in order:
            1. Submit Actions SFastQA
            2. Submit Actions WFastQA
            3. Query Actions
        
            Returns:
                dict with keys 'texts' and 'scores'
        """
        jtr_data = utils.to_jtr_format(
            [self.current_uuid],
            [self.question],
            [''],
            [''],
            [self.current_context],
            self.hp.pad)
        proposals = copy.copy(self.empty_proposals)
        self.current_submitable_actions = []
        ref_texts = []
        ref_scores = []
        original_texts = []
        original_scores = []
        for model in self.models:
            try:
                _ = time()
                jtr_Answers = model.infer(jtr_data)
                self.infer_time.append(time() - _)
            except Exception as e:
                print(e)
                print('\n\n >>>>>>   ', jtr_data)
                self.jtr_data = jtr_data
                raise Exception('Fail')
            for answer in jtr_Answers:

                self.current_submitable_actions.append(answer.text)
                original_texts += [answer.text]
                original_scores += [answer.score]

        ref_texts, ref_scores = self.get_reformulations()

        random_sub_sentences = [utils.get_random_sub_sentence(
            self.current_context)] * (1 + self.hp.reformulations - len(ref_texts))
        random_sub_scores = [utils.cosine(
            self.question, rss) for rss in random_sub_sentences]

        self.current_submitable_actions += random_sub_sentences

        original_scores = [s if s <= 0 else np.log(s)
                           for s in original_scores]
        original_scores = [max(s, -6)
                           for s in original_scores]

        proposals['texts'] += original_texts + random_sub_sentences + ref_texts
        proposals['scores'] += original_scores + random_sub_scores + ref_scores

        proposals['texts'] = [p[:100] for p in proposals['texts']]

        proposals['scores'] = [s if s <= 0 else np.log(s)
                               for s in proposals['scores']]
        self.current_state = proposals
        return proposals

    def step(self, action_id):
        """
            Performs a step in the environment, querying or submiting an action.
            Submit action -> end of episode
            Query Action -> new state. The same context is returned if and only if
                there is no context left matching the query and no other context
                similar to this one.

            Args:
                action_id: int, action to be performed
            
            Returns:
                new state (dict), reward (float), not_over (bool), new title (string)
        """

        step_start_time = time()
        if self.is_state_terminal:
            raise ValueError('Episode is over. Reset environment first.')

        self.current_step += 1
        submit = action_id < self.hp.submitable_actions
        if self.current_step == self.max_steps_per_episode or submit:
            self.is_state_terminal = True

        action = self.current_state['texts'][action_id]

        _ = time()
        if hasattr(self.hp, 'search_in_context') and self.hp.search_in_context:
            self.searched_query = self.searcher.search_context(
                action, limit=2 * self.max_steps_per_episode)
            searched_query = self.searched_query
            if len(searched_query) == 0:
                docnum = self.searcher.searcher.document_number(
                    uuid=self.current_uuid)
                self.more_querry = self.searcher.searcher.more_like(docnum, 'string_sequence',
                                                                    top=15, numterms=10)
                searched_query = self.more_querry
                print('more query')
            else:
                self.more_querry = []
            for i, q in enumerate(searched_query):
                if q['uuid'] not in self.known_episode_uuids:
                    self.current_query = q
                    self.known_episode_uuids.add(q['uuid'])
                    break
                if i == len(q) - 1:
                    self.is_state_terminal = True
                    print('Short episode: %d' % self.current_step)
                    self.current_query = q
                    self.known_episode_uuids.add(q['uuid'])
        else:
            query = self.searcher.search_title(action, limit=1)
            self.search_time.append(time() - _)
            if len(query) == 1:
                # current query is updated if the DB has a result
                # for the query
                self.current_query = query[0]
            else:
                pass

        self.current_context = self.current_query['string_sequence']
        self.current_uuid = self.current_query['uuid']
        self.current_title = self.current_query['title']

        _ = time()
        new_state = self.state()
        self.state_time.append(time() - _)
        reward = self.get_reward(action)

        self.step_time.append(time() - step_start_time)
        return new_state, reward, not self.is_state_terminal, self.current_title

    def get_reward(self, proposal):
        """ 
            Computes the reward accoding to the reward type, proposals and answer

            Args:
                proposal: string which is either queried or submitted

            Returns:
                reward (float)
        """ 
        if self.hp.reward_type == 'instant_cosine':
            if self.is_state_terminal:
                score = utils.score(proposal, self.answer)
                if score == 0 and self.current_step == self.max_steps_per_episode:
                    return -5
                elif score == 0 and not self.current_step == self.max_steps_per_episode:
                    return -2
                else:
                    return 2 * utils.cosine(proposal, self.answer)
            else:
                return 1 / 2 * utils.cosine(proposal, self.answer) - 0.5
        elif self.hp.reward_type == 'instant_score':
            if self.is_state_terminal:
                score = utils.score(proposal, self.answer)
                if score == 0 and self.current_step == self.max_steps_per_episode:
                    return -5
                elif score == 0 and not self.current_step == self.max_steps_per_episode:
                    return -2
                else:
                    return 2 * utils.score(proposal, self.answer)
            else:
                return 1 / 2 * utils.score(proposal, self.answer) - 0.5
        elif self.hp.reward_type == 'improve_cosine':
            if self.is_state_terminal:
                score = utils.score(proposal, self.answer)
                if score == 0 and self.current_step == self.max_steps_per_episode:
                    return -5
                elif score == 0 and not self.current_step == self.max_steps_per_episode:
                    return -2
                else:
                    return 2 * utils.cosine(proposal, self.answer)
            else:
                value = utils.cosine(proposal, self.answer)
                reward = value - self.previous_value_for_reward
                self.previous_value_for_reward = value
                return reward or -0.25
        elif self.hp.reward_type == 'improve_score':
            if self.is_state_terminal:
                score = utils.score(proposal, self.answer)
                if score == 0 and self.current_step == self.max_steps_per_episode:
                    return -5
                elif score == 0 and not self.current_step == self.max_steps_per_episode:
                    return -2
                else:
                    return 2 * utils.cosine(proposal, self.answer)
            else:
                value = utils.score(proposal, self.answer)
                reward = value - self.previous_value_for_reward
                self.previous_value_for_reward = value
                return reward or -0.25
        elif self.hp.reward_type == 'score':
            return utils.score(proposal, self.answer)
        elif self.hp.reward_type == 'cosine':
            return utils.cosine(proposal, self.answer)

    @property
    def empty_proposals(self):
        """
            Decorator returning a dict with empty lists for proposals
            Returns:
                dict
        """
        if not hasattr(self, '_empty_proposals') or 1:
            props = {
                'texts': [],
                'scores': []
            }
            self._empty_proposals = props
        return self._empty_proposals

    def time_stats(self):
        """
            Timing if main Env functions
        """
        print('Mean step_time', np.mean(self.step_time))
        print('Minimum step_time', np.min(self.step_time))
        print('Maximum step_time', np.max(self.step_time))
        print('Std step_time', np.std(self.step_time))
        print('    Mean state_time', np.mean(self.state_time))
        print('    Minimum state_time', np.min(self.state_time))
        print('    Maximum state_time', np.max(self.state_time))
        print('    Std state_time', np.std(self.state_time))
        print('        Mean infer_time', np.mean(self.infer_time))
        print('        Minimum infer_time', np.min(self.infer_time))
        print('        Maximum infer_time', np.max(self.infer_time))
        print('        Std infer_time', np.std(self.infer_time))
        print('    Mean search_time', np.mean(self.search_time))
        print('    Minimum search_time', np.min(self.search_time))
        print('    Maximum search_time', np.max(self.search_time))
        print('    Std search_time', np.std(self.search_time))

    def get_reformulations(self):
        """
            Get current context's Noun Phrases and cosine
            similarity with question

            Retuns:
                tuple(ref_texts, ref_scores) as lists
        """
        doc = self.nlp(self.current_context)
        ref = {str(np): utils.cosine(str(np), self.question)
               for np in doc.noun_chunks}
        sorted_ref = sorted(ref.items(), key=operator.itemgetter(1))[::-1][:5]
        # list of tuples (text, score)

        ref_texts, ref_scores = map(
            list, zip(*sorted_ref)) if len(sorted_ref) > 0 else ([], [])

        return ref_texts, ref_scores


class Jack(object):

    """
        Class aggregating interactions with the jtr models.
        By default using the fastqa model.
    """

    def __init__(self, fastqa_model_path, model_type='fastqa_reader', beam_size=None):
        """
            fastqa_model_path: path to the directory where the pretrained fastqua model
                is stored
            model_type: model to be used. Fastqa by default
        """

        config = {'beam_size': beam_size} if beam_size is not None else None
        tf.reset_default_graph()
        svac = SharedResources(None, None)
        fastqa_reader = readers.readers[model_type](svac)
        fastqa_reader.load_and_setup(fastqa_model_path)
        self.reader = fastqa_reader

    def infer_with_labels(self, jtr_data, verbose=0):
        """
            Infers/predicts answers from a list of jtr-formated instances

            jtr_data: jtr-formated dict with instances in jtr_data['instances']. Use to_jtr_format(...)
                to format lists of fields to a jtr dict
            verbose: if > 0, prints the results of inference
        """
        qa_data = convert2qasettings(jtr_data, max_count=None)
        answers = [a for q, a in qa_data]
        questions = [q for q, a in qa_data]
        proposals = self.reader(questions)
        if verbose > 0:
            for proposal, answer in zip(proposals, answers):
                ss = "{:.4}   Proposal : {}  || Answer : {}  ||  Hop : {}".format(
                     proposal.score, proposal.text, answer[0].text, len(answer[0].span) == 0, )
                print(str.encode(ss, 'utf-8'))
        return proposals, answers, questions

    def infer(self, jtr_data):
        """
            Infers the model's prediction

            Args:
                jtr_data: dict formated for JTR

            returns: 
                list of model's inferences
        """

        qa_data = convert2qasettings(jtr_data, max_count=None)
        questions = [q for q, a in qa_data]
        return self.reader(questions)[0]


class Searcher(object):
    """
        Class aggregating interactions with the whoosh indexed Whoosh DB.

        Schema of the index:
            answer_location -> ** json-serialized ** list answer word indexes in the context
            answer_string_sequence -> answer (as string)
            question_string_sequence -> original Wikireading question (as string) (= categories)
            question -> reformulated question in a SQuAD way
            string_sequence -> context's text
            uuid -> unique id for the instance
            title -> Title parsed from the wikipedia link
            hop -> boolean, whether the answer is in the context (False) or not (True)
    """

    def __init__(self, whoosh_path, data_source, multi=False):
        """
            whoosh_path : path to the whoosh directory containing the indexes
            data_source : train test or validation
        """
        if not multi:
            self.whoosh_path = whoosh_path
            self.index_location = whoosh_path + data_source + '_index'
            self.data_source = data_source
            self.ix = index.open_dir(self.index_location)
            self.searcher = self.ix.searcher()
            self.title_qp = QueryParser("title", schema=self.ix.schema)
            self.uuid_qp = QueryParser("uuid", schema=self.ix.schema)
            self.context_qp = QueryParser(
                "string_sequence", schema=self.ix.schema)

    def search_title(self, title_to_search, limit=20):
        """
        title_to_search : string to be searched in the 'title' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """

        q = self.title_qp.parse("'" + title_to_search + "'")
        return [dict(r) for r in self.searcher.search(q, limit=limit)]

    def search_context(self, context_to_search, limit=20):
        """
        context_to_search : string to be searched in the 'string_sequence' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """

        q = self.context_qp.parse("'" + context_to_search + "'")
        return [dict(r) for r in self.searcher.search(q, limit=limit)]

    def search_uuid(self, uuid_to_search, limit=None):
        """
        uuid_to_search : string to be searched in the 'uuid' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        q = self.uuid_qp.parse("'" + uuid_to_search + "'")
        return [dict(r) for r in self.searcher.search(q, limit=limit)]

    def search_uuids(self, uuids_to_search, limit=None):
        """
        The query is parsed as a sequence of OR statements

        uuids_to_search : list of strings to be searched in the 'uuid' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        uuids = ' OR '.join(uuids_to_search)
        q = self.uuid_qp.parse(uuids)
        return [dict(r) for r in self.searcher.search(q, limit=limit)]

    def get_qa_data(self, uuids_to_search):
        """
            Function to get the fields necessary for the jtr format from a list of uuids

            uuids_to_search : list of uuids (as strings)

            returns : a tuple containing the necessary fields:
                uuids_, questions_, answers_, answer_locations_, texts_
        """
        uuids_ = []
        questions_ = []
        answers_ = []
        answer_locations_ = []
        texts_ = []
        results = self.search_uuids(uuids_to_search, limit=None)
        for r in results:
            uuids_.append(r['uuid'])
            questions_.append(r['question'])
            answers_.append(r['answer_string_sequence'])
            answer_locations_.append(json.loads(r['answer_location']))
            texts_.append(r['string_sequence'])
        return uuids_, questions_, answers_, answer_locations_, texts_


class MultiSearcher(Searcher):

    """
        ~~OSOLETE~~
            This class is not actually used as Whoosh searchers are not picklable 
            so we can not uses processes and threads do not speed up computations

        Class aggregating interactions with the whoosh indexed Whoosh DB.

        Schema of the index:
            answer_location -> ** json-serialized ** list answer word indexes in the context
            answer_string_sequence -> answer (as string)
            question_string_sequence -> original Wikireading question (as string) (= categories)
            question -> reformulated question in a SQuAD way
            string_sequence -> context's text
            uuid -> unique id for the instance
            title -> Title parsed from the wikipedia link
            hop -> boolean, whether the answer is in the context (False) or not (True)
    """

    def __init__(self, whoosh_path, data_source, created=True):
        """
            whoosh_path : path to the whoosh directory containing the indexes
            data_source : train test or validation
        """
        super().__init__(whoosh_path, data_source, multi=True)
        self.n_multi = 2
        if 'ubuntu' in utils.get_dev_path():
            self.n_multi = 5
        self.whoosh_path = whoosh_path
        self.index_locations = sorted(
            [whoosh_path + f for f in os.listdir(whoosh_path) if 'index' in f])
        self.data_source = data_source
        if created:
            self.ixs = []
            self.searchers = []
            for il in self.index_locations:
                print('Loading ', il)
                ix = index.open_dir(il)
                self.ixs += [ix]
                self.searchers += [ix.searcher()]
            self.title_qp = QueryParser("title", schema=self.ixs[0].schema)
            self.uuid_qp = QueryParser("uuid", schema=self.ixs[0].schema)
            self.context_qp = QueryParser(
                "string_sequence", schema=self.ixs[0].schema)

    def create_from_searcher(self, env_searcher):
        """
            Initializes a new searcher from another one

            Args:
                env_seracher: Environment.Searcher instance to be copied

        """
        if 'yes' not in input(
                'About to erase and rewrite the multi-whoosh indexes. Continue? (yes/no) '):
            print('Aborting')
            return
        self.title_qp = QueryParser("title", schema=env_searcher.ix.schema)
        self.uuid_qp = QueryParser("uuid", schema=env_searcher.ix.schema)
        self.context_qp = QueryParser(
            "string_sequence", schema=env_searcher.ix.schema)
        self.ixs = []

        self.whoosh_path = env_searcher.whoosh_path[:-1] + '_multi/'
        if not os.path.exists(self.whoosh_path):
            os.mkdir(self.whoosh_path)
        else:
            shutil.rmtree(self.whoosh_path)
            os.mkdir(self.whoosh_path)

        self.index_locations = [self.whoosh_path + env_searcher.data_source + '_index' + str(i)
                                for i in range(self.n_multi)]
        for il in self.index_locations:
            os.mkdir(il)
        self.schema = env_searcher.ix.schema
        self.uuids = [env_searcher.uuids[i * len(env_searcher.uuids) // self.n_multi:
                                         (i + 1) * len(env_searcher.uuids) // self.n_multi]
                      for i in range(self.n_multi)]
        with open(self.whoosh_path + '/uuid_dataset.pkl', 'wb') as f:
            pkl.dump(env_searcher.uuids, f)

        for n in range(self.n_multi):
            print('Creating ', self.index_locations[n])
            ix = index.create_in(
                self.index_locations[n], self.schema)
            self.ixs.append(ix)
            writer = ix.writer()
            print('Parsing uuids')
            uuid_qp = QueryParser("uuid", schema=env_searcher.ix.schema)
            uuids_to_search = self.uuids[n]
            uuids = ' OR '.join(uuids_to_search)
            q = uuid_qp.parse(uuids)
            print('To list')
            to_write = [dict(r)
                        for r in env_searcher.searcher.search(q, limit=None)]
            print('Writing')
            for k, result in enumerate(to_write):
                writer.add_document(answer_location=result["answer_location"],
                                    answer_string_sequence=result['answer_string_sequence'],
                                    question_string_sequence=result['question_string_sequence'],
                                    question=result['question'],
                                    string_sequence=result['string_sequence'],
                                    uuid=result['uuid'],
                                    title=result['title'],
                                    hop=len(result['answer_location']) == 2)
                print('\r', k, end='')
            writer.commit()
        self.searchers = [ix.searcher() for ix in self.ixs]
        print('Done')

    def search_context(self, context_to_search, limit=20):
        """
        context_to_search : string to be searched in the 'string_sequence' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        pool = Pool(self.n_multi)

        args_context_to_search = [context_to_search] * self.n_multi
        args_limit = [limit] * self.n_multi
        args = zip([_ for _ in range(self.n_multi)],
                   args_context_to_search, args_limit)
        temp_result = pool.map(self.subprocess_search_context, args)
        pool.close()
        pool.join()
        result = []
        for r in temp_result:
            if len(r['results']) > 0:
                result.append(r)
        if len(result) == 0:
            return []
        if limit is None:
            queries = np.array([], dtype=object)
            scores = np.array([], dtype=float)
            for r in result:
                queries = np.concatenate((queries, r['results']), axis=0)
                scores = np.concatenate((scores, r['scores']), axis=0)
        else:
            queries = np.zeros([self.n_multi * limit], dtype=object)
            scores = np.zeros([self.n_multi * limit], dtype=float)
            start = 0
            for r in result:
                end = start + len(r['results'])
                scores[start:end] = r['scores']
                queries[start:end] = r['results']
                start = end
        limit = limit or 0
        best_k = scores.argsort()[-limit:][::-1]
        self.queries = queries[best_k]
        return queries[best_k]

    def search_title(self, title_to_search, limit=20):
        """
        title_to_search : string to be searched in the 'title' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        pool = Pool(self.n_multi)

        args_title_to_search = [title_to_search] * self.n_multi
        args_limit = [limit] * self.n_multi
        args = zip([_ for _ in range(self.n_multi)],
                   args_title_to_search, args_limit)
        temp_result = pool.map(self.subprocess_search_title, args)
        pool.close()
        pool.join()
        result = []
        for r in temp_result:
            if len(r['results']) > 0:
                result.append(r)
        if len(result) == 0:
            return []
        if limit is None:
            queries = np.array([], dtype=object)
            scores = np.array([], dtype=float)
            for r in result:
                queries = np.concatenate((queries, r['results']), axis=0)
                scores = np.concatenate((scores, r['scores']), axis=0)
        else:
            queries = np.zeros([self.n_multi * limit], dtype=object)
            scores = np.zeros([self.n_multi * limit], dtype=float)
            start = 0
            for r in result:
                end = start + len(r['results'])
                scores[start:end] = r['scores']
                queries[start:end] = r['results']
                start = end
        limit = limit or 0
        best_k = scores.argsort()[-limit:][::-1]
        self.queries = queries[best_k]
        return queries[best_k]

    def search_uuid(self, uuid_to_search, limit=None):
        """
        uuid_to_search : string to be searched in the 'uuid' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        pool = Pool(self.n_multi)

        args_uuid_to_search = [uuid_to_search] * self.n_multi
        args_limit = [limit] * self.n_multi

        args = zip([_ for _ in range(self.n_multi)],
                   args_uuid_to_search, args_limit)
        temp_result = pool.map(self.subprocess_search_uuid, args)
        pool.close()
        pool.join()
        result = []
        for r in temp_result:
            if len(r['results']) > 0:
                result.append(r)
        if len(result) == 0:
            return []

        if limit is None:
            queries = np.array([], dtype=object)
            scores = np.array([], dtype=float)
            for r in result:
                queries = np.concatenate((queries, r['results']), axis=0)
                scores = np.concatenate((scores, r['scores']), axis=0)
        else:
            queries, scores = [np.zeros([self.n_multi * limit])] * 2
            start = 0
            for r in result:
                end = start + len(r['results'])
                scores[start:end] = r['scores']
                queries[start:end] = r['results']
                start = end
        limit = limit or 0
        best_k = scores.argsort()[-limit:][::-1]
        return queries[best_k]

    def search_uuids(self, uuids_to_search, limit=None):
        """
        The query is parsed as a sequence of OR statements

        uuids_to_search : list of strings to be searched in the 'uuid' field
        limit : upper bound on the number of results returned

        returns: list of dicts with whoosh fields as keys
        """
        uuids_query = ' OR '.join(uuids_to_search)
        pool = Pool(self.n_multi)

        args_uuids_query = [uuids_query] * self.n_multi
        args_limit = [limit] * self.n_multi

        args = zip([_ for _ in range(self.n_multi)],
                   args_uuids_query, args_limit)
        temp_result = pool.map(self.subprocess_search_uuids, args)
        pool.close()
        pool.join()
        result = []
        for r in temp_result:
            if len(r['results']) > 0:
                result.append(r)
        if len(result) == 0:
            return []
        if limit is None:
            queries = np.array([], dtype=object)
            scores = np.array([], dtype=float)
            for r in result:
                queries = np.concatenate((queries, r['results']), axis=0)
                scores = np.concatenate((scores, r['scores']), axis=0)
        else:
            queries, scores = [np.zeros([self.n_multi * limit])] * 2
            start = 0
            for r in result:
                end = start + len(r['results'])
                scores[start:end] = r['scores']
                queries[start:end] = r['results']
                start = end
        limit = limit or 0
        best_k = scores.argsort()[-limit:][::-1]
        return queries[best_k]

    def subprocess_search_title(self, args):
        searcher_id, title_to_search, limit = args
        q = self.title_qp.parse(
            "'" + title_to_search + "'")
        results = self.searchers[searcher_id].search(q, limit=limit)
        return {'results': [dict(r) for r in results],
                'scores': [r.score for r in results]}

    def subprocess_search_uuid(self, args):
        searcher_id, uuid_to_search, limit = args
        q = self.uuid_qp.parse(
            "'" + uuid_to_search + "'")
        results = self.searchers[searcher_id].search(q, limit=limit)
        return {'results': [dict(r) for r in results],
                'scores': [r.score for r in results]}

    def subprocess_search_uuids(self, args):
        searcher_id, uuids_query, limit = args
        q = self.uuid_qp.parse(uuids_query)
        results = self.searchers[searcher_id].search(q, limit=limit)
        return {'results': [dict(r) for r in results],
                'scores': [r.score for r in results]}

    def subprocess_search_context(self, args):
        searcher_id, context_to_search, limit = args
        q = self.context_qp.parse(
            "'" + context_to_search + "'")
        results = self.searchers[searcher_id].search(q, limit=limit)
        return {'results': [dict(r) for r in results],
                'scores': [r.score for r in results]}
