import os
import _io
import copy
import numpy as np
import pickle as pkl
import utils
from time import time
import tensorflow as tf
from importlib import reload
from numpy.random import choice, randint, random

reload(utils)
np.random.seed(2)


def get_dev_path():
    """
        returns the dev folder's location depending on whether it is run
        on a mac or ubuntu
        jtr should be ../jtr/ w.r.t. dev
    """
    if "Users" in os.listdir('/'):
        return "/Users/victor/Documents/UCL/Courses/project/code/dev/"
    else:
        return "/home/ubuntu/dev/"


def get_save_path(dev_path):
    """
        returns a new path to save the models.
        Save directories are named as integers within
        the models/ directory. A new path is max(save_dirs) + 1
    """
    if not os.path.exists(dev_path + 'models/'):
        os.mkdir(dev_path + 'models/')
    path = dev_path + 'models/'
    model_dirs = [d for d in os.listdir(path) if os.path.isdir(path + d)]
    max_dir = 0
    for d in model_dirs:
        try:
            temp_dir = int(d)
            if temp_dir >= max_dir:
                max_dir = temp_dir
        except ValueError:
            continue
    _id = str(max_dir + 1)
    return path + _id + '/'


class AbstractHp(object):
    """
        Abstract class from which Hyper Parameters (HP) inherit.
    """
    def __init__(self):
        self.training_step = 0
        self.episode_count = 0
        self.batch_count = 0
        self.param_type = None
        self.decay_epsilon = None
        self.base_epsilon = None
        self._save_path = None
        self.open = None
        self.log_path = None
        self.extended_open = None
        self.submitable_actions = None
        self.embedding_file = None
        self.interaction_layers = None
        self.save_every_step = None
        self.val_every_step = None
        self.write_every_step = None
        self.train_with_generator = None
        self.properties = ['args', 'decayed_epsilon', 'epsilon',
                           'save_path', 'log_file', 'extended_log_file']

    @property
    def args(self):
        """
            list of the HPs fields
        """
        return sorted([s for s in dir(self)
                       if '__' not in s
                       and s not in self.properties
                       and hasattr(self, s)
                       and 'reset' not in s
                       and not callable(self.__getattribute__(s))
                       and not isinstance(self.__getattribute__(s), property)])

    @property
    def decayed_epsilon(self):
        """
            property returning the decayed epsilon for the epsilon-greedy 
            policy. Decay is either linear or exponential.
        """
        # Saturation at 19 000 steps
        start_epsilon = self.base_epsilon
        if self.decay_strategy == 'exponential':
            drate = 0.97
            stp = self.training_step
            ds = 1000

            tmp = max(start_epsilon * drate ** (stp / ds), self.min_epsilon)
            self.current_epsilon = tmp
            return tmp
        else:
            # returns base epsilon when training_step = 0
            # returns min_epsilon after 10 000 steps
            a = self.min_epsilon - self.base_epsilon
            a /= self.total_steps
            b = self.base_epsilon - a
            stp = self.training_step
            tmp = max(a * self.training_step + b, self.min_epsilon)
            self.current_epsilon = tmp
            return tmp

    @property
    def epsilon(self):
        """
            returns the epsilon-greedy's epsilon
        """
        if self.decay_epsilon and self.training_step > 0:
            return self.decayed_epsilon
        return self.base_epsilon

    @property
    def save_path(self):
        def __call__(self):
            pass
        """
            defines the agent's path in the __init__ but only creates the directory
            if ever called
        """
        if not os.path.exists(self._save_path):
            os.mkdir(self._save_path)
        return self._save_path

    @property
    def log_file(self):
        """
            retuns either an opened file to log prints into or creates one and
            opens it in append mode
        """
        if not self.open and not (
                hasattr(self, 'set_log') and self.set_log):
            self._log_file = open(self.log_path, 'a')
            self.open = True
        return self._log_file

    @log_file.setter
    def log_file(self, value):
        """
            log_file property setter
        """
        print('Setter')
        self._log_file.close()
        self.open = False
        self._log_file = value
        self.set_log = True

    @property
    def extended_log_file(self):
        """
            same as log_file, for all prints
        """
        if not self.extended_open and not (
                hasattr(self, 'set_extended_log') and self.set_extended_log):
            self._extended_log_file = open(
                self.log_path[:-3] + 'extended_log', 'a')
            self.extended_open = True
        return self._extended_log_file

    @extended_log_file.setter
    """
        idem
    """
    def extended_log_file(self, value):
        self._extended_log_file.close()
        self.extended_open = False
        self._extended_log_file = value
        self.set_extended_log = True

    def lr_decay(self, learning_rate, global_step, d_s=200, d_r=0.95):
        return tf.maximum(tf.train.exponential_decay(learning_rate, global_step, decay_steps=d_s, decay_rate=d_r), 0.0001)


class MetaHP(AbstractHp):
    """
        Class of HPs for learner, aggregating logger, agent, env and network HPs, 
        called sub-hps
    """
    def __init__(self):
        """
            sets attributess from default values in sub-hps without redundance
        """
        super().__init__()

        self.ap = HyperParameter('agent')
        self.ap.dropout = 0.9

        self.ep = HyperParameter('env', save_path=self.ap._save_path)
        self.ep.init_date = self.ap.init_date
        self.ep.init_time = self.ap.init_time

        self.lp = HyperParameter('learner', save_path=self.ap._save_path)
        self.lp.init_date = self.ap.init_date
        self.lp.init_time = self.ap.init_time

        self.logp = HyperParameter(
            'logger', policy=self.ap.policy, save_path=self.ap._save_path)
        self.logp.init_date = self.ap.init_date
        self.logp.init_time = self.ap.init_time

        ignore = []
        for k in self.ap.default_args:
            if k not in ['save_path', 'param_type', 'properties', '_save_path']:
                ignore.append(k)
                # self.ep.__delattr__(k)
                # self.lp.__delattr__(k)
                # self.logp.__delattr__(k)

        self.hps = [self.ep, self.ap, self.lp, self.logp]

        for hp in self.hps:
            for k in dir(hp):
                if k not in ['__weakref__'] + self.properties\
                        and hasattr(hp, k) and '__' not in k:
                    attr = hp.__getattribute__(k)
                    if attr is not None:
                        self.__setattr__(k, attr)
        self.set_attrs = True
        _ = self.save_path

    def __setattr__(self, attr, val):
        """
            Sets hte meta hp's new attribute and updates the relevant sub-hp.
            If the meta hp is being randomized, it prints the new values.
        """
        if hasattr(self, 'set_attrs'):
            if attr in self.ep.args:
                self.ep.__setattr__(attr, val)
            if attr in self.ap.args:
                self.ap.__setattr__(attr, val)
            if attr in self.lp.args:
                self.lp.__setattr__(attr, val)
            if attr in self.logp.args:
                self.logp.__setattr__(attr, val)
        if hasattr(self, 'randomizing'):
            if self.randomizing:
                print('{:20}{:20} : {}'.format(
                    '', attr, val
                ))
        super(MetaHP, self).__setattr__(attr, val)

    def __str__(self):
        """
            String method printing all arguments one by line sorted in 
            alpha-numerical order
        """
        # s = 'Agent params:\n'
        # s += str(self.ap)
        # s += '\nEnv params:\n'
        # s += str(self.ep)
        # s += '\nLearner params:\n'
        # s += str(self.lp)
        # s += '\nLogger params:\n'
        # s += str(self.logp)
        s = 'MetaHP: \n'
        args = {d: str(self.__getattribute__(d)) for d in dir(self)
                if 'log_file' not in d and '__' not in d
                and not callable(self.__getattribute__(d))
                and not isinstance(self.__getattribute__(d), HyperParameter)
                and 'args' not in d and 'hps' not in d
                }
        for k in sorted(args.keys()):
            s += '{:25} : {}\n'.format(k, args[k])
        return s

    def dump(self):
        """
            Dumps the MetaHP as a pickled dictionnary in the save_path
        """
        with open(self.save_path + 'hyperparameters_description.txt', 'w') as f:
            f.write(str(self))
        hp = copy.copy(self)
        dic = hp.__dict__
        with open(self.save_path + 'hyperparameters.pkl', 'wb') as f:
            pkl.dump({d: dic[d] for d in dic
                      if not isinstance(dic[d], _io.TextIOWrapper)}, f)

    def randomize(self):
        """
            Randomizes a special set of attributes for the Random Search.
            As per __setattr__ these are printed along randomization.
        """
        np.random.seed()

        def choose(arr):
            return choice(
                arr, p=np.ones([len(arr)]) / len(arr))

        print('Randomizing')
        bs = [64, 128, 256, 512]

        teps = [1, 2, 5, 10, 20, 50]
        psts = [int(1e3), int(5e3), int(1e4),
                int(1.5e4), int(2e4), int(2.5e4),
                int(5e4)]
        soft_eps = [0.1, 0.15, 0.2, 0.25, 0.3]
        min_eps = [0., 0.05, 0.1]

        policies = ['epsilon_greedy', 'softmax', 'softmax_epsilon']
        decay_strategies = ['batch', 'episode',
                            'exponential', 'else', 'onlyexpoothersarelinear']
        reward_types = ['instant_cosine', 'improve_score', 'improve_cosine', 'instant_score']
        opts = ['Adam', 'RMSProp']

        base_eps = list(range(5, 11))
        self.randomizing = True
        self.init_time = time()
        self.init_date = utils.ts_to_date(self.init_time)
        self.update_every = randint(1, 11) * 10
        self.episode_count = 0 if (
            random() > 0.5) else -1 * randint(1, 11) * 1000
        self.batch_count = 0 if (
            random() > 0.5) else -1 * randint(1, 11) * 1000
        self.train_episodes = choose(teps)
        self.training_buffers = self.total_steps // self.train_episodes
        self.randomize_past = True if random() < 0.6 else False

        self.delay = randint(0, 6) * 1000 
        self.training_step -= self.delay
        self.past_size = choose(psts)
        self.batch_size = choose(bs)
        self.policy = choose(policies)
        self.decay_strategy = choose(decay_strategies)
        self.base_epsilon = choose(base_eps) * 0.1
        self.softmax_epsilon = choose(soft_eps)
        self.optimizer = choose(opts)
        self.reward_type = choose(reward_types)
        self.min_eps = choose(min_eps)

        self.randomizing = False
        self.randomized = True


class HyperParameter(AbstractHp):
    """
        Class defining Hyperparameters used in Agents, Networks, Environments and to log
        information into file instead of printing it in the stdout.

        They are sub-hps to the MetaHP
    """
    def __init__(self, param_type=None, policy=None, save_path=None):
        super().__init__()
        self.dev_path = get_dev_path()
        self._save_path = save_path or get_save_path(self.dev_path)
        self.param_type = param_type
        self.init_time = time()
        self.init_date = utils.ts_to_date(self.init_time)
        self.env_model_nb = 2
        self.oov = '<oov>'
        self.pad = '<pad>'
        self.pad_action = '<pad_action>'

        self.policy = policy
        self.reformulations = 5
        self.submitable_actions = self.env_model_nb * 5 + 1
        self.default_args = [
            a for a in self.args if self.__getattribute__(a) is not None]
        self.set_type_args(param_type)
        self.total_steps = 12500
        self.total_action_nb = self.reformulations + self.submitable_actions

    def __str__(self):
        """
            String representation is the list of args with their value
        """
        print_string = ""
        for a in self.args:
            print_string += '{:25} :  {}\n'.format(a,
                                                   str(self.__getattribute__(a)))
        return print_string

    def __repr__(self):
        return 'agent.HyperParameter with args : ' + ', '.join(self.args)

    def reset(self):
        """
            Sets values to default 
        """
        temp = HyperParameter(self.param_type)
        for attr in temp.args:
            self.__setattr__(attr, temp.__getattribute__(attr))

    def set_type_args(self, param_type):
        """
            Sets the default values according to the hyperparameter's type
            which is logger, agent, env or learner
        """
        if param_type == 'agent':
            self.training_step = 0
            self.lr = 0.001
            self.clip_value = 10.0
            self.dense_layers = [64, 64, 32]
            self.optimizer = 'Adam'
            self.interaction_layers = [
                64, 32, 1]
            self.use_interaction = True
            self.lambda_reg = 0.0001

            self.softmax_alpha = 1.0
            self.decay_epsilon = True
            self.base_epsilon = 1.0
            self.min_epsilon = 0.1
            self.softmax_epsilon = 0.1
            self.discount = 0.95
            self.policy = 'epsilon_greedy'
            self.decay_strategy = 'linear'

            self.prioritize = True
            if self.prioritize:
                self.per_beta0 = 0.4
                self.prio_max = 0
                self.per_epsilon = 1e-6
                self.per_alpha = 0.8

            self.save = True
            self.embedding_file = self.dev_path + '../jtr/data/GloVe/glove.6B.50d.txt'
            self.reset_default_graph = False

            self.load_model = ''

            self.double = True

        elif param_type == 'env':
            jtr_path = self.dev_path[:-4] + 'jtr/'
            self.model_paths = [jtr_path + 'fastqa_reader/',
                                jtr_path + 'fastqa_wikireading_reader1/']
            self.whoosh_path = self.dev_path + 'whoosh_data/mini/'
            self.beam_size = 5
            self.data_source = 'train'
            self.multi = False
            self.n_multi = 5 if 'ubuntu' in self.dev_path else 2
            if self.multi:
                self.whoosh_path = self.whoosh_path[:-1] + '_multi/'
            self.reward_type = 'instant_cosine'
            self.max_steps_per_episode = 15

            self.train_only_use_hops = False
            self.val_only_use_hops = True
            self.search_in_context = True

        elif param_type == 'learner':

            self.training_buffers = 250
            self.train_episodes = 200
            self.validation_episodes = 100
            self.final_validation_episodes = 1000

            self.save_every = 50
            self.save_every_step = 15000
            self.val_every = 10
            self.val_every_step = 500
            self.update_every = 200
            self.write_every_step = 1000

            self.past_size = int(1.5e4)
            self.randomize_past = False
            self.batch_size = 128
            self.training_step = 0
            self.current_buffer = 0

            self.randomize_hp = False

            self.train_with_generator = True

            self.delay = 3000
            self.training_step -= self.delay

        elif param_type == 'logger':
            self.log = True
            self.log_path = self._save_path + self.policy + '_'
            self.log_path += self.init_date + '.log'
            self.open = False
            self.extended_open = False
            self.original_print = print
            self.description = """
            Double DQN w/ Prioritized
            Val only on hops
            1000 val eps
            Search Context not title
            New Rewards -> instant score
            Never get same context in episode
            """[:-13]
