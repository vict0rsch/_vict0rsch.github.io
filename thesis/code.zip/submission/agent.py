import os
import sys
import time
import numpy as np
import network as net
import utils
import tensorflow as tf
sys.path.append('~/jtr/')
sys.path.append('../jtr/')
from importlib import reload
import hyperparameter as hyp
from tensorflow.contrib.layers import xavier_initializer, fully_connected

reload(net)
reload(hyp)
reload(utils)
np.random.seed(2)
tf.set_random_seed(2)


class Agent(object):
    """
        The Agent encapsulates all computations in the DRRN.
        Its main attributes are Agent.question_net and Agent.action_net
        representin the Question and Action Networks.

        * Agent.compile() creates the graph
        * Agent.initialize_variables() itinializes the variables. If the 
            hyper parameters has a load_model field then weights are loaded
            instead of running the default initializers
        * Agent.optimize() sets the optimizer variables (and the Tensorboard vars)
        * Agent.run_action_distribution() returns the Q-value distribution (
            softmaxed)

        Any inner variable may be run in Agent.sess wich is a Tensorflow Session

        @utils.time_() decorators print the running time of any function. 
        Prints the function's name by default but can print a string passed
        as argument
    """

    def __init__(self, hyperparams=None):

        self._hp = hyperparams or hyp.HyperParameter('agent')

        self.current_step = 0
        self.oov = self._hp.oov
        self.pad = self._hp.pad
        self.pad_action = self._hp.pad_action

        self.emb_matrix = None
        self.emb_vocab = None
        self.loss = None
        self.current_q_value_for_action = None
        self.next_q_value_per_action = None

        if self._hp.reset_default_graph:
            tf.reset_default_graph()
        self.graph = tf.get_default_graph()
        self.sess = tf.Session(graph=self.graph)
        self.reward_ph = tf.placeholder(tf.float32,
                                        [None],
                                        'reward_ph')
        self.global_step = tf.Variable(0,
                                       'global_step_ph')
        self.state_is_not_terminal_ph = tf.placeholder(tf.float32,
                                                       [None],
                                                       name='state_is_not_terminal_ph')
        self.saver = tf.train.Saver(max_to_keep=1)
        self.action_net = net.Action_Network(self._hp)
        self.question_net = net.Question_Network(self._hp)
        self.embedding_file = self.hp.embedding_file

    @property
    def hp(self):
        """
            constantly updates networks' hyp.HyperParameters when the agent's is modified
        """
        self.action_net.hp = self._hp
        self.question_net.hp = self._hp
        return self._hp

    def set_hp(self, hp):
        self.action_net.hp = hp
        self.question_net.hp = hp
        self._hp = hp

    # @utils.time_()
    def compile(self, matrix=None, vocab=None):
        """
            Creates the tensorflow graph:
            1) set the embedding matrix
            2) compute the networks' output to compute the Q-value
            3) create the Q-value variables :
                a) for the current time step t and current action
                b) for the next time step t+1 over all possible actions at t+1
            4) create the value to select an action at play-time
            5) implement Q-learning:
                loss = mean( delta^2 )
                delta = Reward(t+1) + Gamma * \
                               max_a( Q(s_t+1, a) ) - Q(s_t, a_t)
        """

        self.set_embedding_matrix(self.embedding_file, matrix, vocab)
        self.question_net.set_output_tensors()
        self.action_net.set_output_tensors()

        self.set_current_q_value_for_action()
        self.set_next_target_q_value_per_action()

        # self.argmax_q = tf.reshape(
        #     tf.argmax(self.current_q_value_for_action, axis=0),
        #     [1])
        if self.hp.double:
            self.set_next_q_value_per_action()
            self.double_optimize()
        else:
            self.optimize()

    # @utils.time_()
    def run_action_distribution(self, question, actions, submitable_action,
                                query_scores, submit_scores):
        """
            Get softmax policy from current state (question, actions)

            question : list of words (strings)
            actions : list of list of words (strings)

            returns : numpy 1D array of size len(actions)
        """
        actions = self.lookup_words_2D(actions)
        question = self.lookup_words_2D([question] * len(actions))

        feed_dict = {
            self.action_net.current_action_word_count_ph: [len(l) for l in actions],
            self.action_net.current_action_ph: actions,
            self.action_net.current_action_submit_score_ph: submit_scores,
            self.action_net.current_action_query_score_ph: query_scores,
            self.action_net.current_action_submit_ph: submitable_action,
            self.action_net.dropout_ph: 1.0,
            self.question_net.question_ph: question,
            self.question_net.question_word_count_ph: [len(question)],
            self.question_net.dropout_ph: 1.0,
        }

        self.run_action_feed_dict = feed_dict

        action_distribution = self.sess.run(
            self.softmaxed_q_value,
            feed_dict=feed_dict)
        return action_distribution

    # @utils.time_()
    def initialize_variables(self):
        """
            Initializes the tensorboard writer and the tensorflow graph.
            If self.hp has a load_model field, this model is used to initialize the
            variables
        """
        self.train_writer = tf.summary.FileWriter(
            self.hp.save_path + 'tensorboard/', self.graph)
        self.merged = tf.summary.merge_all()
        if len(self.hp.load_model) > 0:

            try:
                # embedding_initializers = [
                #     var.initializer for var in tf.global_variables()
                #     if 'embedding_tensor' in var.name
                #     and 'submit' not in var.name
                # ]
                # self.sess.run(embedding_initializers)
                self.saver.restore(self.sess, self.hp.load_model)
            except:
                if 'y' in input('Could not load model %s | Load another?' % self.hp.load_model):
                    model_to_load = input('Model location? :  ')
                    self.hp.second_model_to_load = model_to_load
                    self.saver.restore(self.sess, self.hp.second_model_to_load)
                else:
                    raise ValueError('Could not load model. Aborting.')
        else:
            tf.global_variables_initializer().run(session=self.sess)

    def lookup_words_2D(self, list_of_word_lists, max_len=None):
        """
            Looks up and pads lists of word lists from the embedding vocab using the
            self.oov and self.pad tokens

            returns : numpy 2D array of size len(list_of_word_lists) * max(len(l) for l in list_of_word_lists)
        """
        list_of_word_lists = [l if isinstance(l, list) else [l]
                              for l in list_of_word_lists]
        embedded_list_of_lists = [
            [min(self.emb_vocab.get(w.lower(), self.emb_vocab[self.oov]), 400004)
             for w in word_list]
            for word_list in list_of_word_lists]
        max_len = max_len or max([len(l) for l in embedded_list_of_lists])
        return np.array([l + [self.emb_vocab[self.pad]] * (max_len - len(l))
                         for l in embedded_list_of_lists])

    def lookup_words_3D(self, action_3D_list):
        max_action_nb = max([len(l) for l in action_3D_list])
        max_action_length = max([len(a) for l in action_3D_list for a in l])
        looked_up_2D = [self.lookup_words_2D(
            l, max_action_length) for l in action_3D_list]
        looked_up_3D = []
        for l in looked_up_2D:
            if l.shape[0] < max_action_nb:
                for _ in range(max_action_nb - l.shape[0]):
                    l = np.concatenate(
                        [l,
                         np.expand_dims(
                             np.array(
                                 [self.emb_vocab[self.pad_action]] * max_action_length),
                             axis=0)],
                        axis=0)
            looked_up_3D.append(l)
        return np.array(looked_up_3D)

    def optimize(self):
        """
            Computes the Q-learning error (loss) and sets the opt_op

            returns None
        """
        with tf.variable_scope('Loss'):
            with tf.variable_scope('MaxNextQValue'):
                max_q = tf.stop_gradient(
                    tf.reshape(
                        tf.reduce_max(
                            self.next_target_q_value_per_action, axis=1),
                        [-1]
                    )
                )
            y = self.hp.discount * max_q * self.state_is_not_terminal_ph
            y += self.reward_ph
            self.y = y
            delta = y - self.current_q_value_for_action
            self.delta2 = delta

            loss = 0.5 * tf.reduce_mean(tf.square(delta))
            loss += self.hp.lambda_reg * self.regularizer()
            self.loss = loss
        with tf.variable_scope('AgentOptimizer'):
            opt_op = tf.contrib.layers.optimize_loss(loss, self.global_step, self.hp.lr, self.hp.optimizer,
                                                     learning_rate_decay_fn=self.hp.lr_decay,
                                                     clip_gradients=self.hp.clip_value,
                                                     summaries=["loss", "learning_rate"])

        self.opt_op = opt_op

    def double_optimize(self):
        """
            Computes the Q-learning error (loss) and sets the opt_op
            for the Double Q-learning setting

            returns None
        """
        with tf.variable_scope('Loss'):
            with tf.variable_scope('ArgmaxNextQValue'):
                self.argmax_q = tf.stop_gradient(
                    tf.cast(
                        tf.reshape(
                            tf.argmax(self.next_q_value_per_action, axis=1),
                            [-1, 1]
                        ),
                        tf.int32
                    )
                )
            with tf.variable_scope('MaxTargetQValue'):
                self.indices = tf.concat(
                    [
                        tf.reshape(
                            tf.range(0, tf.shape(self.argmax_q)[0]),
                            [-1, 1]),
                        self.argmax_q
                    ],
                    axis=1
                )
                self.max_q = tf.reshape(tf.gather_nd(
                    self.next_target_q_value_per_action, self.indices),
                    [-1])
            y = self.hp.discount * self.max_q * self.state_is_not_terminal_ph
            y += self.reward_ph
            self.y = y
            delta = y - self.current_q_value_for_action
            if self.hp.prioritize:
                self.weight_is_ph = tf.placeholder(
                    tf.float32, shape=[None], name='weight_is_ph')
                delta = tf.multiply(delta, self.weight_is_ph)
            self.delta = delta
            self.delta2 = tf.square(delta)

            loss = tf.reduce_mean(self.delta2)
            loss += self.hp.lambda_reg * self.regularizer()
            self.loss = loss
        with tf.variable_scope('AgentOptimizer'):
            opt_op = tf.contrib.layers.optimize_loss(loss, self.global_step, self.hp.lr, self.hp.optimizer,
                                                     learning_rate_decay_fn=self.hp.lr_decay,
                                                     clip_gradients=self.hp.clip_value,
                                                     summaries=["loss", "learning_rate"])

        self.opt_op = opt_op

    def phs(self):
        """
            prints a list of all the agent's placeholders with their source
        """
        phs_agent = [p for p in dir(self) if '_ph' in p]
        phs_action = [p for p in self.action_net.phs()]
        phs_question = [p for p in self.question_net.phs()]
        print('Placeholders:\nAgent: ' + ', '.join(sorted(phs_agent)),
              '\n', 'Action_Net : ', ', '.join(sorted(phs_action)),
              '\n', 'Question_Net : ', ', '.join(sorted(phs_question)))

    def save_model(self, name=None):
        """
            Saves the model's weights in the HP's save_path

            name: optional string for the save's name. If None then
                name is 'default'

            returns None
        """

        name = name or 'default'
        self.saver.save(sess=self.sess, save_path=self.hp.save_path +
                        name)
        self.hp.save_location = self.hp.save_path + name

    def set_embedding_matrix(self, embedding_file, matrix=None, vocab=None):
        """
            Sets the Agent and its Networks' embedding matrices and vocabs

            embedding_file: string with the loadtion of the embedding matrice
                with weights and tokens
            matrix: optional, embedding matrix to be used, prevents loading of the 
                embedding_file matrix if not None
            vocab: matrix's vocabulary tokens

            returns None
        """

        if self.emb_vocab is None and self.emb_matrix is None:
            if matrix is None and vocab is None:
                with open(embedding_file, 'r') as f:
                    vocab, matrix = utils.load_glove(f)

            self.reverse_vocab = {
                v + 3: k for k, v in vocab.items()}

            self.reverse_vocab[0] = self.oov
            self.reverse_vocab[1] = self.pad
            self.reverse_vocab[2] = self.pad_action

            self.emb_vocab = {v: k for k, v in self.reverse_vocab.items()}
            self.emb_matrix = np.vstack(
                (np.zeros((2, matrix.shape[1])), matrix))
            # emb_matrix lacks the OOV first line which will be learned in TF
        self.embedding_size = self.emb_matrix.shape[1]
        if self.action_net.emb_vocab is None:
            self.reverse_vocab = {v: k for k, v in self.emb_vocab.items()}
            self.action_net.set_embedding_variable(
                self.emb_vocab, self.emb_matrix)
            self.question_net.set_embedding_variable(
                self.emb_vocab, self.emb_matrix)

    def set_networks_outputs(self):
        """
            Calls the Networks' set_output_tensors()

            raises Exception if embedding matrix is not initialized

            returns None
        """
        if self.emb_matrix is not None:
            self.action_net.set_output_tensors()
            self.question_net.set_output_tensors()
        else:
            raise Exception(
                'Embeddings are not set. Use set_embedding_matrix(\
                self, embedding_file) first')

    def set_next_target_q_value_per_action(self):
        """
            Creates the Tensorflow Variable representing the Q value for the 
            next step which is to be maxed over in the TD Error. This Q value
            is computed from the Target Network.

            returns None 
        """

        acts = self.action_net.actions_for_next_state
        question = self.question_net.question
        target_question = self.question_net.target_question

        if not self.hp.use_interaction:
            with tf.variable_scope('ConcatSubmitActions'):
                acts = tf.concat(
                    (tf.tile(tf.expand_dims(self.submit_variable, 0),
                             [tf.shape(acts)[0], 1, 1]),
                     acts),
                    axis=1)
            with tf.variable_scope('NextQValuePerAction'):
                with tf.variable_scope('TileQuestion'):
                    question = tf.tile(
                        tf.expand_dims(question, 1),
                        [1, tf.shape(acts)[1], 1]
                    )
                self.next_q_value_per_action = utils.batch_dot_3D(
                    acts, question)
        else:
            with tf.variable_scope('NSTargetInteractionInput'):
                with tf.variable_scope('TileQuestion'):
                    target_question = tf.tile(
                        tf.expand_dims(target_question, 1),
                        [1, tf.shape(acts)[1], 1]
                    )
                submit_tokens_3D = self.get_submit_tokens()

                submit_score = tf.expand_dims(
                    self.action_net.next_actions_submit_score_ph, axis=2)
                query_score = tf.expand_dims(
                    self.action_net.next_actions_query_score_ph, axis=2)
                input_tensor = tf.concat((
                    target_question,
                    acts,
                    submit_score,
                    query_score,
                    submit_tokens_3D),
                    axis=2)

            self.next_target_q_value_per_action = self.get_target_interaction(
                input_tensor)

    def set_next_q_value_per_action(self):
        """
            Creates the Tensorflow Variable representing the Q value for the 
            next step. This is called only if a target network is not used.

            returns None
        """

        acts = self.action_net.actions_for_next_state
        question = self.question_net.question

        with tf.variable_scope('NSInteractionInput'):
            with tf.variable_scope('TileQuestion'):
                question = tf.tile(
                    tf.expand_dims(question, 1),
                    [1, tf.shape(acts)[1], 1]
                )
            submit_tokens_3D = self.get_submit_tokens()

            submit_score = tf.expand_dims(
                self.action_net.next_actions_submit_score_ph, axis=2)
            query_score = tf.expand_dims(
                self.action_net.next_actions_query_score_ph, axis=2)
            input_tensor = tf.concat((
                question,
                acts,
                submit_score,
                query_score,
                submit_tokens_3D),
                axis=2)

        self.next_q_value_per_action = self.get_interaction(input_tensor)

    def set_current_q_value_for_action(self):
        """
            Sets the Agent's Tensorflow variable representing the current Q value
            wich is substracted in the TD error 

            returns None
        """
        act = self.action_net.action_for_current_state
        ques = self.question_net.question
        if not self.hp.use_interaction:
            with tf.variable_scope('CurrentQValueForAction'):
                self.current_q_value_for_action = utils.batch_dot_2D(act, ques)
        else:
            with tf.variable_scope('CSInteractionInput'):
                submit_tokens_2D = tf.expand_dims(
                    self.action_net.current_action_submit_ph,
                    axis=1)

                submit_score = tf.expand_dims(
                    self.action_net.current_action_submit_score_ph, axis=1)
                query_score = tf.expand_dims(
                    self.action_net.current_action_query_score_ph, axis=1)
                input_tensor = tf.concat((
                    ques,
                    act,
                    submit_score,
                    query_score,
                    submit_tokens_2D),
                    axis=1)
            self.current_q_value_for_action = tf.reshape(
                self.interaction_layer(
                    input_tensor, False, 'InteractionLayer'),
                [-1]
            )

        with tf.variable_scope('SoftmaxQValueForAction'):
            self.softmaxed_q_value = tf.nn.softmax(
                tf.reshape(self.current_q_value_for_action,
                           [-1]) * self.hp.softmax_alpha
            )

    def interaction_layer(self, input_tensor, reuse, scope):
        """
            Computes the Interaction Network's output from a variable.

            input_tensor: input variable wich is to be passed through the 
                Netwtork
            reuse: whether to reuse existing variables or create new ones
            scope: scope encapsulating the variable's creations

            returns: Variable 
        """
        scope = scope or 'InteractionLayer'
        with tf.variable_scope(scope, reuse=reuse):
            local_tensor = input_tensor
            xav = xavier_initializer()
            for i, l in enumerate(self.hp.interaction_layers[:-1]):
                local_tensor = fully_connected(local_tensor,
                                               l,
                                               biases_initializer=xav,
                                               reuse=reuse,
                                               scope='fully_connected_' + str(
                                                   i) if scope is not None else None,
                                               activation_fn=utils.selu
                                               )
            i += 1
            last = fully_connected(local_tensor,
                                   self.hp.interaction_layers[-1],
                                   activation_fn=None,
                                   biases_initializer=xav,
                                   reuse=reuse,
                                   scope='fully_connected_' + str(
                                       i) if scope is not None else None,
                                   )
        return last

    def get_target_interaction(self, input_tensor):
        """
            Computes the output of an input variable through the Interaction
            target network.

            retunrs: Variable
        """

        return utils.fixed_linear_with_logits(
            input_tensor,
            self.hp.interaction_layers,
            'Interaction')

    def get_interaction(self, input_tensor):
        """
            returns the output through the already existing
            Interaction Network of the input tensor

            input_tensor: Variable

            returns: Variable
        """
        return self.interaction_layer(
            input_tensor, True, 'InteractionLayer')

    def get_submit_tokens(self):
        """
            returns a tensorflow binary variable stating whether an action
            is a submit action or a query action
        """
        with tf.variable_scope("SubmitTokens"):

            bs = tf.shape(self.action_net.next_actions_ph)[0]
            max_nb_acts = tf.shape(self.action_net.next_actions_ph)[1]
            nb_submit_acts = self.hp.submitable_actions
            tokens = tf.concat(
                (tf.ones([1, nb_submit_acts]),
                 tf.zeros([1, max_nb_acts - nb_submit_acts])
                 ), axis=1)
            tokens_2D = tf.expand_dims(tokens, axis=2)
            tokens_3D = tf.tile(tokens_2D, [bs, 1, 1])
        return tokens_3D

    def regularizer(self, norm='l2'):
        """
            norm: optional, default l2, norm to be used in the regularization

            returns the sum of the norms of trainable variables
            in the graph
        """

        with tf.variable_scope('L2Norms'):
            trainable_variables = [t for t in self.graph.get_collection('trainable_variables')
                                   if 'fully_connected_' in t.name]
            if norm == 'l2':
                loss = tf.nn.l2_loss
            else:
                raise ValueError('Unknown norm')

            return np.sum(
                [loss(t) for t in trainable_variables]
            )
