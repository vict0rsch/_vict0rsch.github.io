import os
import json
import utils
import math
import numpy as np
import pandas as pd
import pickle as pkl
import seaborn as sns
import matplotlib.pyplot as plt


class Analyzer:
    """
        Helper class to explore results of experiments.
        Not detailed as not part of the actual project.
        Main role is to store resutls in Pandas DataFrame
        and drop Latex Tables
    """

    def __init__(self, initialized=True):
        self.path = utils.get_dev_path() + 'experiments/'
        self.initialized = initialized
        self.df_pickle_path = self.path + 'dataframe.pkl'
        self.rdf_pickle_path = self.path + 'relevant_dataframe.pkl'
        self.stop_keys = {'ap', 'ep', 'logp', 'lp',
                          'lr_decay', 'reset', 'set_type_args',
                          'hps', 'original_print', 'default_args',
                          'model_paths', 'whoosh_path', 'properties', 'model_paths',
                          'embedding_file'}
        self.table_path = self.path + 'Tables/'
        self.tables = [
            'shortbaselinetable',
            'baselinetable',
            'firstmodelbaseline',
            'secondmodelbaseline',
            'thirdmodelbaseline',
            'fourthmodelbaseline',
            'uohbaseline',
            'fifthmodelbaseline',
            'gridbaseline',
            'sixthmodelbasline'
        ]
        if initialized:
            self.df = pd.read_pickle(self.df_pickle_path)
        self.baseline_path = utils.get_dev_path() + 'models/Baselines/full/'
        try:
            self.bdf = pd.read_pickle(self.path + 'bdf.pkl')
        except:
            pass

    @property
    def rdf(self):
        if not hasattr(self, 'df'):
            raise NotImplementedError('No DataFrame')
        keys = [
            'exp_dir', 'bl_improvement', 'mean_return', 'std_return', 'mean_return_only_use_hops',
            'std_return_only_use_hops', 'mean_return_use_any', 'std_return_use_any',
            'partial_success', 'partial_success_only_use_hops',
            'partial_success_use_any', 'reward_type', 'discount', 'val_only_use_hops',
            'base_epsilon', 'batch_size',
            'decay_strategy', 'delay', 'description',
            'double', 'final_validation_episodes',
            'min_eps', 'min_epsilon',
            'optimizer', 'past_size', 'policy', 'prioritize',
            'randomize_hp', 'randomize_past', 'search_in_context',
            'total_steps', 'train_episodes', 'train_only_use_hops',
            'train_with_generator', 'training_buffers', 'update_every',
            'exp_path'
        ]
        rdf = self.df.loc[:, keys]
        convert_keys = ['mean_return', 'std_return', 'mean_return_only_use_hops',
                        'std_return_only_use_hops', 'mean_return_use_any', 'std_return_use_any']
        for k in convert_keys:
            rdf[k] = rdf[k].apply(
                lambda x: float('{:.3f}'.format(x))
            )

        return rdf

    def create_baseline(self):
        with open(self.baseline_path + 'baseline_plays.pkl', 'rb') as f:
            bls = pkl.load(f)
        index = 0
        for policy in bls:
            for rt in bls[policy]:
                for discount in bls[policy][rt]:
                    for uoh in bls[policy][rt][discount]:
                        print('\r', index, end='')
                        store = bls[policy][rt][discount][uoh]
                        partial_success = len([1 for epr in store['rewards'] for r in epr
                                               if r > 0])
                        d = {
                            'policy': policy,
                            'reward_type': rt,
                            'discount': discount,
                            'only_use_hops': uoh == 'use_only_hops',
                            'mean_return': store['mean_return'],
                            'std_return': store['std_return'],
                            'partial_success': partial_success,
                            'ep_nb': len(store['rewards'])
                        }
                        if index == 0:
                            self.bdf = pd.DataFrame(d, index=[index])
                        else:
                            self.bdf = pd.concat((
                                self.bdf,
                                pd.DataFrame(d, index=[index])),
                                axis=0)
                        index += 1
        self.bdf.to_pickle(self.path + 'bdf.pkl')
        self.bdf.to_excel(self.path + 'baselines.xls')

    def bl(self, row):
        if row['reward_type'] == 'cosine':
            return -1000
        disc = row['discount'] if row['discount'] != 0.95 else 1
        bl = self.bdf.loc[
            (self.bdf.reward_type == row['reward_type']) &
            (self.bdf.discount == disc) &
            (self.bdf.only_use_hops == row['val_only_use_hops'])
        ]['mean_return'].max()
        mr = row['mean_return']
        if math.isnan(mr):
            mr = max(row['mean_return_only_use_hops'],
                     row['mean_return_use_any'])

        return 100 * (mr - bl) / abs(bl)

    def get_baseline(self, iloc):
        row = self.df.iloc[iloc]
        disc = row['discount'] if row['discount'] != 0.95 else 1
        self.temp_bl = self.bdf.loc[
            (self.bdf.reward_type == row['reward_type']) &
            (self.bdf.discount == disc) &
            (self.bdf.only_use_hops == row['val_only_use_hops'])
        ]['mean_return']
        self.bl_max = self.temp_bl.max()
        self.mr = row['mean_return']
        if math.isnan(self.mr):
            self.mr = max(row['mean_return_only_use_hops'],
                          row['mean_return_use_any'])

        return 100 * (self.mr - self.bl_max) / abs(self.bl_max)

    def add_baseline(self, force=False):
        if 'bl_improvement' in self.df.columns and not force:
            if 'y' not in input('Baseline Improvement already computed. Overwrite?'):
                return
        self.df['bl_improvement'] = self.df.apply(
            lambda row: self.bl(row),
            axis=1)
        if not force and 'y' in input('Dump?'):
            self.dump()

    def dump_rdf(self):
        self.rdf.to_pickle(self.rdf_pickle_path)
        self.rdf.to_excel(self.path + 'rdf_experiments.xls')

    def update(self):
        self.exps = get_experiments()
        adds = 0
        for i, exp_path in enumerate(self.exps):
            if exp_path[65:] in self.df['exp_path'].values:
                continue
            print('\r', i, end='')
            hp = get_hp_and_plot_val_store(exp_path, plot=False)
            fss = get_and_print_final(exp_path, verbose=0)
            if hp is not None:
                hp['exp_path'] = exp_path[65:]
                if fss is not None:
                    if len(fss) == 1:
                        fs = fss['final_store']
                        hp['mean_return'] = fs['mean_return']
                        hp['std_return'] = fs['std_return']
                        hp['partial_success'] = sum(
                            [1 if r[-1] > -2 else 0 for r in fs['rewards']])
                    else:
                        for k, fs in fss.items():
                            hp['mean_return_%s' % k] = fs['mean_return']
                            hp['std_return_%s' % k] = fs['std_return']
                            hp['partial_success_%s' % k] = sum(
                                [1 if r[-1] > -2 else 0 for r in fs['rewards']])
                self.add_hp(hp)
                adds += 1
        print('\n Added', adds, 'values')

        self.df['exp_dir'] = self.df['exp_path'].apply(
            lambda x: x.split('/')[0]
        )
        self.add_baseline(True)
        if 'y' in input('\nDump? '):
            self.dump()

    def dump(self):
        self.df.to_pickle(self.df_pickle_path)
        self.df.to_excel(self.path + 'experiments.xls')
        if 'y' in input('\nDump rdf?'):
            self.dump_rdf()

    def add_hp(self, hp):
        if not self.initialized:
            raise ValueError('Not initialized')
        to_fill = []
        jhp = self.get_clean_json_hp(hp)
        for k, v in jhp.items():
            if k not in self.df.columns:
                default = get_default(k, v, jhp)
                to_fill.append((k, default))
        self.df = pd.concat((
            self.df,
            pd.DataFrame(
                jhp,
                index=[len(self.df)]
            )),
            axis=0
        )
        for tupl in to_fill:
            try:
                k, default = tupl
                self.df[k] = self.df[k].fillna(default)
            except Exception as e:
                print(k, default)
                raise ValueError(e)

    def initialize(self):
        if 'y' in input('Are you sure you want to initialize the DB? '):
            print()
            self.initialized = True
            self.exps = get_experiments()
            self.hps = {}
            self.fs = {}
            for i, exp_path in enumerate(self.exps):
                print('\r', i, end='')
                hp = get_hp_and_plot_val_store(exp_path, plot=False)
                self.hps[exp_path] = hp
                fss = get_and_print_final(exp_path, verbose=0)
                self.fs[exp_path] = fss

                if hp is not None:
                    hp['exp_path'] = exp_path[65:]
                    if fss is not None:
                        if len(fss) == 1:
                            fs = fss['final_store']
                            hp['mean_return'] = fs['mean_return']
                            hp['std_return'] = fs['std_return']
                            hp['partial_success'] = sum(
                                [1 if r[-1] > -2 else 0 for r in fs['rewards']])
                        else:
                            for k, fs in fss.items():
                                hp['mean_return_%s' % k] = fs['mean_return']
                                hp['std_return_%s' % k] = fs['std_return']
                                hp['partial_success_%s' % k] = sum(
                                    [1 if r[-1] > -2 else 0 for r in fs['rewards']])
                if i == 0:
                    jhp = self.get_clean_json_hp(hp)
                    self.df = pd.DataFrame(jhp, index=[0])
                else:
                    self.add_hp(hp)

    def get_clean_json_hp(self, hp):
        jhp = {}
        for k in hp:
            if k not in self.stop_keys:
                value = hp[k]
                st = str(type(value))
                if 'numpy' in st:
                    if 'int' in st:
                        value = int(value)
                    elif 'float' in st:
                        value = float(value)
                    elif 'array' in st:
                        value = value.tolist()
                if isinstance(value, list):
                    value = json.dumps(value)
                jhp[k] = value
        self.jhp = jhp
        return jhp

    def drop_latex_tables(self):
        for t in self.tables:
            print(t)
            self.drop_latex_table(t)

    def drop_latex_table(self, table_name, caption=""):
        if table_name == 'shortbaselinetable':
            td = self.bdf.loc[
                (self.bdf.policy == 'submit_0') &
                (self.bdf.reward_type != 'score') &
                (self.bdf.reward_type != 'cosine')
            ]
            td = td.sort(['mean_return'], ascending=[False])
            td['P. Success'] = td['partial_success']
            td['mean(\\mathbi{R})'] = td['mean_return'].apply(
                lambda x: float('{:.3f}'.format(x))
            )
            td['std(\\mathbi{R})'] = td['std_return'].apply(
                lambda x: float('{:.3f}'.format(x))
            )
            td = td[['mean(\\mathbi{R})', 'partial_success',
                     'reward_type', 'discount', 'std(\\mathbi{R})', 'only_use_hops']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "SFastQA baseline, for each type of reward, validation set and discount.")
        elif table_name == 'baselinetable':
            td = self.bdf.copy()
            td = td.loc[
                (td.reward_type != 'score') &
                (td.reward_type != 'cosine')]
            td = td.sort(['policy', 'mean_return'],
                         ascending=[True, False])
            td['mean(\\mathbi{R})'] = td['mean_return'].apply(
                lambda x: float('{:.3f}'.format(x))
            )
            td['std(\\mathbi{R})'] = td['std_return'].apply(
                lambda x: float('{:.3f}'.format(x))
            )
            td = td[['policy', 'mean(\\mathbi{R})', 'partial_success',
                               'reward_type', 'discount', 'std(\\mathbi{R})', 'only_use_hops']]
            l = len(td)
            nb = 4
            for j in range(nb):
                temp = td.iloc[j * l // nb: (j + 1) * l // nb]
                temp.to_latex(self.table_path + table_name + str(j) +
                              '.latex_table', index=False)
                format_table(self.table_path + table_name + str(j) +
                             '.latex_table', table_name, 'Baselines')
            merge_files([self.table_path + table_name + str(j) +
                         '.latex_table' for j in range(nb)],
                        self.table_path + table_name + '.latex_table')
        elif table_name == 'firstmodelbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '1 No Selu No Reg')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return']
            td['std(\\mathbi{R})'] = td['std_return']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'P. Success',
                     'std(\\mathbi{R})', 'reward_type', 'batch_size', 'Epsilon',
                     'decay_strategy']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "First model results, Baseline Improvement in percentages")
        elif table_name == 'secondmodelbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '2 Reg and Selu')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return']
            td['std(\\mathbi{R})'] = td['std_return']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'P. Success',
                     'std(\\mathbi{R})', 'reward_type', 'batch_size', 'Epsilon',
                     'decay_strategy']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Second model results, Baseline Improvement in percentages")
        elif table_name == 'thirdmodelbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '3 Target')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return']
            td['std(\\mathbi{R})'] = td['std_return']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'P. Success',
                     'std(\\mathbi{R})', 'reward_type', 'batch_size', 'Epsilon',
                     'decay_strategy', 'optimizer']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Third model results, Baseline Improvement in percentages")
        elif table_name == 'fourthmodelbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '4 DDQN Prioritized')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return']
            td['std(\\mathbi{R})'] = td['std_return']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'P. Success',
                     'std(\\mathbi{R})', 'reward_type', 'batch_size', 'Epsilon',
                     'decay_strategy', 'optimizer']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Fourth model results, Baseline Improvement in percentages")
        elif table_name == 'uohbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '5 DDQNP use_only_hops Train & Val')
                    | (td.exp_dir == '6 DDQNP use_only_hops Val')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['T. O. H.'] = td['train_only_use_hops']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return']
            td['std(\\mathbi{R})'] = td['std_return']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'P. Success',
                     'std(\\mathbi{R})', 'reward_type', 'batch_size', 'Epsilon',
                     'decay_strategy', 'T. O. H.']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Fourth model results, always validating only on instances with hops")
        elif table_name == 'fifthmodelbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '8 DDQNP uoh val context new rewards')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return_use_any']
            td['std(\\mathbi{R})'] = td['std_return_use_any']
            td['mean(\\mathbi{R}) O. H.'] = td['mean_return_only_use_hops']
            td['std(\\mathbi{R}) O. H.'] = td['std_return_only_use_hops']
            td['P. S.'] = td['partial_success_use_any']
            td['P. S. O. H.'] = td['partial_success_only_use_hops']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'mean(\\mathbi{R}) O. H.', 'P. S.', 'P. S. O. H.',
                     'std(\\mathbi{R})', 'std(\\mathbi{R}) O. H.', 'reward_type', 'batch_size']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Fifth model results, always validating only on instances with hops")
        elif table_name == 'gridbaseline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '9 DDQNP uoh val new rewards search') &
                    (td.reward_type != 'score') &
                    (td.reward_type != 'cosine')]

            td = td.sort(['reward_type', 'bl_improvement'],
                         ascending=[False, False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return_use_any']
            td['std(\\mathbi{R})'] = td['std_return_use_any']
            td['mean(\\mathbi{R}) O. H.'] = td['mean_return_only_use_hops']
            td['std(\\mathbi{R}) O. H.'] = td['std_return_only_use_hops']
            td['P. S.'] = td['partial_success_use_any']
            td['Memory'] = td['past_size']
            td['P. S. O. H.'] = td['partial_success_only_use_hops']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'mean(\\mathbi{R}) O. H.', 'P. S.', 'P. S. O. H.',
                     'std(\\mathbi{R})', 'std(\\mathbi{R}) O. H.', 'reward_type', 'optimizer', 'discount', 'Memory']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Grid model results, always validating only on instances with hops")
        elif table_name == 'sixthmodelbasline':
            td = self.rdf.copy()
            td = td[(td.exp_dir == '11 DDQNP uoh val context new rewards more_like')]
            td = td.sort(['bl_improvement'], ascending=[False])
            td['baseline_improvement'] = td['bl_improvement'].apply(
                lambda x: float('{:.1f}'.format(x))
            )
            td['P. Success'] = td['partial_success']
            td['B. I.'] = td['baseline_improvement']
            td['Epsilon'] = td['base_epsilon']
            td['decay_strategy'] = td['decay_strategy'].apply(
                lambda x: x if x == 'exponential' else 'linear'
            )
            td['mean(\\mathbi{R})'] = td['mean_return_use_any']
            td['std(\\mathbi{R})'] = td['std_return_use_any']
            td['mean(\\mathbi{R}) O. H.'] = td['mean_return_only_use_hops']
            td['std(\\mathbi{R}) O. H.'] = td['std_return_only_use_hops']
            td['P. S.'] = td['partial_success_use_any']
            td['P. S. O. H.'] = td['partial_success_only_use_hops']
            td = td[['B. I.', 'mean(\\mathbi{R})', 'mean(\\mathbi{R}) O. H.', 'P. S.', 'P. S. O. H.',
                     'std(\\mathbi{R})', 'std(\\mathbi{R}) O. H.', 'reward_type', 'discount']]
            td.to_latex(self.table_path + table_name +
                        '.latex_table', index=False)
            format_table(self.table_path + table_name +
                         '.latex_table', table_name,
                         "Sixth model results, always validating only on instances with hops")

    def gdf_(self):
        sns.set(style="white", rc={"axes.facecolor": (0, 0, 0, 0)})
        self.mods = {
            '1 No Selu No Reg': 1,
            '2 Reg and Selu': 2,
            '3 Target': 3,
            '4 DDQN Prioritized': 4,
            '5 DDQNP use_only_hops Train & Val': 4,
            '6 DDQNP use_only_hops Val': 4,
            '8 DDQNP uoh val context new rewards': 5,
            '9 DDQNP uoh val new rewards search': 5,
            '11 DDQNP uoh val context new rewards more_like': 6

        }
        self.dirs = {
            '1 No Selu No Reg': 1,
            '2 Reg and Selu': 2,
            '3 Target': 3,
            '4 DDQN Prioritized': 4,
            '5 DDQNP use_only_hops Train & Val': 5,
            '6 DDQNP use_only_hops Val': 6,
            '8 DDQNP uoh val context new rewards': 8,
            '9 DDQNP uoh val new rewards search': 9,
            '11 DDQNP uoh val context new rewards more_like': 11

        }

        def get_mean_return(row):
            if self.mods[row['exp_dir']] in {1,2,3,4}:
                return row['mean_return']
            else:
                return row['mean_return_use_any']
        def get_std_return(row):
            if self.mods[row['exp_dir']] in {1,2,3,4}:
                return row['std_return']
            else:
                return row['std_return_use_any']

        gdf = self.rdf
        self.gdf = gdf
        self.gdf['select_model'] = gdf['exp_dir'].apply(
            lambda x: x in set(self.mods.keys())
        )
        self.gdf = self.gdf[(self.gdf.select_model == True)]

        self.gdf['model'] = self.gdf['exp_dir'].apply(
            lambda x: self.mods[x]
        )
        self.gdf.keep_reward = self.gdf.reward_type.apply(
            lambda x: x in {'instant_score', 'instant_cosine', 'improve_score', 'improve_cosine'} 
        )
        self.gdf = self.gdf[(self.gdf.keep_reward == True)] 
        self.gdf.mean_return = self.gdf.apply(
            lambda row: get_mean_return(row), axis=1
        )
        self.gdf.std_return = self.gdf.apply(
            lambda row: get_std_return(row), axis=1
        )

    def plot_bl_hist(self):
        self.gdf_()
        self.pdf = self.gdf
        self.pdf['keep_dir'] = self.pdf['exp_dir'].apply(
            lambda x: self.dirs[x] in {1,2,3,4,5,6}  
        )

        bldf = self.gdf[['model','reward_type', 'bl_improvement']]
        bldf['value'] = bldf['bl_improvement']
        bldf['metric'] = bldf['bl_improvement'].apply(
            lambda x: 'B. I.')
        bldf['reward_type'] = bldf['reward_type']
        bldf = bldf[['model', 'metric', 'reward_type', 'value']]
        idx = bldf.groupby(['reward_type', 'model'])['value'].transform(max) == bldf['value']
        bldf = bldf[idx]

        mrdf = self.gdf[['model','reward_type', 'mean_return']]
        mrdf['value'] = mrdf['mean_return']
        mrdf['metric'] = mrdf['mean_return'].apply(
            lambda x: 'mean(R)')
        mrdf['reward_type'] = mrdf['reward_type']
        mrdf = mrdf[['model', 'metric', 'reward_type', 'value']]
        idx = mrdf.groupby(['reward_type', 'model'])['value'].transform(max) == mrdf['value']
        mrdf = mrdf[idx]

        stdrdf = self.gdf[['model','reward_type', 'std_return']]
        stdrdf['value'] = stdrdf['std_return']
        stdrdf['metric'] = stdrdf['std_return'].apply(
            lambda x: 'std(R)')
        stdrdf['reward_type'] = stdrdf['reward_type']
        stdrdf = stdrdf[['model', 'metric', 'reward_type', 'value']]
        idx = stdrdf.groupby(['reward_type', 'model'])['value'].transform(min) == stdrdf['value']
        stdrdf = stdrdf[idx]

        self.plotdf = pd.concat((bldf, mrdf, stdrdf), axis= 0)
        self.plotdf = self.plotdf.sort(['reward_type', 'metric', 'model'], ascending=[True, True, True])

        g = sns.factorplot(data=self.plotdf, x='reward_type', y='value', kind='bar',
                   col='metric', col_wrap=2, sharey=False, hue='model')
        g.set(xlabel='', ylabel='')
        plt.show()
        


def get_default(key, obj, hp=None):
    if key in {'train_only_use_hops',
               'val_only_use_hops', 'search_in_context'}:
        return False
    if key == 'randomize_hp' and 'randomizing' in hp:
        return True
    else:
        return False
    t = str(type(obj))
    if 'list' in t:
        return []
    elif 'int' in t:
        return 0
    elif 'float' in t:
        return 0.0
    elif 'dict' in t:
        return {}
    elif 'str' in t:
        return ''
    elif 'bool' in t:
        return None


def get_experiments():
    dev_path = utils.get_dev_path()
    exp_path = dev_path + 'experiments/'
    exps = []
    for exp_dir in os.listdir(exp_path):
        if exp_dir not in {'Old', 'Table'}:
            if os.path.isdir(exp_path + exp_dir):
                exps += [exp_path + exp_dir + '/' + f + '/'
                         for f in os.listdir(exp_path + exp_dir)
                         if os.path.isdir(exp_path + exp_dir + '/' + f)]
    return sorted(exps)


def get_hp_and_plot_val_store(exp_path, plot=False):
    with open(exp_path + 'val_stores.pkl', 'rb') as f:
        val_stores = pkl.load(f)
    with open(exp_path + 'hyperparameters.pkl', 'rb') as f:
        hp = pkl.load(f)
    if not isinstance(hp, dict):
        return None
    if plot:
        x = hp['val_every'] * (np.arange(len(val_stores)) + 1)
        x *= hp['train_episodes']
        fig = plt.figure()
        fig.suptitle(exp_path)
        plt.plot(x, [v['mean_return'] for v in val_stores])
        plt.show(block=False)
    return hp


def format_table(location, name, caption=''):
    with open(location, 'r') as f:
        lines = f.readlines()
    tw = ['\\begin{table}[h]\n',
          '\\centering\n',
          '\\resizebox{\\textwidth}{!}{%\n']

    if lines[2][:2] == '{}':
        lines[2] = lines[3][:lines[3].index('&')] + lines[2][2:]
        lines[3] = '%\n'

    fields = lines[2].split(' & ')
    fields[-1] = fields[-1][:-3]
    fields = [
        ' '.join([s.capitalize() for s in f.split('\\_')])
        for f in fields
    ]
    fields = [
        ' '.join([s.capitalize() for s in f.split(' ')])
        for f in fields
    ]
    fields = [
        ' '.join([s.capitalize() for s in f.split('\\') if len(s) > 1])
        for f in fields
    ]
    fields = [
        ' '.join([s.capitalize() for s in f.split(' ') if len(s) > 1])
        for f in fields
    ]

    lines[2] = ' & '.join(fields) + '\\\\ \n'
    lines[2] = lines[2].replace(' Textbackslashmathbi {r }', '$\\mathbi{R}$')

    tw += lines[:-1]
    tw += [
        '\\end{tabular}%\n',
        '}\n',
        '\\caption{%s}\n' % caption,
        '\\label{%s}\n' % name,
        '\\end{table}\n'
    ]
    with open(location, 'w') as f:
        f.writelines(tw)


def merge_files(files, dest):
    l = [
        open(f, 'r').readlines() for f in files
    ]

    ll = []
    for lll in l:
        ll += lll
        ll += ['\n']

    with open(dest, 'w') as f:
        f.writelines(ll)


def get_and_print_final(exp_path, verbose=1):
    if not 'final_store.pkl' in os.listdir(exp_path):
        if not 'use_any_final_store.pkl' in os.listdir(exp_path):
            print('No use_any_final_store in %s' % (
                exp_path.split('/')[-2] + ' ' + exp_path.split('/')[-1]
            ))
            return
        else:
            multiple = True
            fstores = {'use_any': 0, 'only_use_hops': 0}
            with open(exp_path + 'use_any_final_store.pkl', 'rb') as f:
                fstores['use_any'] = pkl.load(f)
            with open(exp_path + 'only_use_hops_final_store.pkl', 'rb') as f:
                fstores['only_use_hops'] = pkl.load(f)
    else:
        multiple = False
        with open(exp_path + 'final_store.pkl', 'rb') as f:
            fs = pkl.load(f)

    fss = {'final_store': fs} if not multiple else fstores

    # Keys: ['possible_actions', 'returns', 'actions_taken', 'questions',
    # 'mean_return', 'std_return', 'titles', 'episode_length', 'rewards',
    # 'possible_actions_scores', 'answers', 'actions_taken_score', 'length']
    if verbose > 0:

        for k, fs in fss.items():
            print(exp_path, k)
            kv = '{:25}: {}'
            print(kv.format('mean_return', fs['mean_return']))
            print(kv.format('partial successes (/%d)' % len(fs['rewards']),
                            sum([1 if r[-1] > -2 else 0 for r in fs['rewards']])
                            ))
            print(kv.format(
                'exact',
                sum([1 if 1.99 < r[-1] < 2.01 else 0 for r in fs['rewards']])
            ))
    return fss


def get_analysis(fs):
    an = {
        'submit': 0,
        'unique_query': 0,
        'various_query_no_submit': 0,
        'query_then_submit': 0,
        'various_queries': []
    }
    episodes = len(fs['actions_taken'])

    for ep in range(episodes):
        if len(set(fs['actions_taken'][ep])) == 1:
            an['unique_query'] += 1
        else:
            submit = False
            prevent = False
            for i in range(len(fs['actions_taken'][ep])):
                if fs['possible_actions'][ep][i].index(
                    fs['actions_taken'][ep][i]
                ) <= 9:
                    if i == 0:
                        an['submit'] += 1
                        prevent = True
                    else:
                        submit = True
            if submit and not prevent:
                an['query_then_submit'] += 1
            elif not submit and not prevent:
                an['various_query_no_submit'] += 1
                an['various_queries'].append(
                    len(set(fs['actions_taken'][ep])) /
                    len(fs['actions_taken'][ep])
                )
    return an


def print_fs(fs):
    episodes = len(fs['actions_taken'])
    for ep in range(episodes):
        print('Ep {} Question {} Answer {}'.format(
            ep, fs['questions'][ep], fs['answers'][ep]
        ))
        for i, a in enumerate(fs['actions_taken'][ep]):
            print('    {}'.format(a))


if __name__ == '__main__':
    exps_paths = get_experiments()
    fstores = {}
    for i, exp in enumerate(exps_paths):
        if 'DDQN' not in exp:
            continue
        hp = get_hp_and_plot_val_store(exp, plot=False)
        if hp is not None and 'description' in hp:
            print('\n', i, '> Description : ',
                  hp['description'], '\n', hp['reward_type'])
        final_store = get_and_print_final(exp)
        if final_store is not None:
            fstores[exp] = final_store

    bl = {pol: {} for pol in bls['improve_score'].keys() if pol not in {
        'description', 'submitable_actions'}}
    for rt in bls:
        b = bls[rt]
        for pol in b:
            if pol not in {'description', 'submitable_actions'}:
                for rtt in b[pol]:
                    bl[pol][rt] = b[pol][rtt]
