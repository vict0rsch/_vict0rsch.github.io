import os
import sys
import shutil
import env as rle
import agent as ag
import numpy as np
import pickle as pkl
import utils as utils
from copy import copy
import tensorflow as tf
import data_structures as ds
from time import time, sleep
from importlib import reload
import hyperparameter as hyp
from numpy.random import permutation, choice

reload(ag)
reload(rle)
reload(hyp)
reload(utils)
reload(ds)
np.random.seed(2)
tf.set_random_seed(2)


class Learner():
    """
        Class describing the learning algorithms. It has an Agent which can
        be trained according to several procedures, tested, saved.
    """
    # @utils.time_('Learner init')
    def __init__(self, randomize=False, agent=None, env=None,
                 searcher=None, models=None, log=None):
        """
            Args:
                radomize: bool, whether or not to randomize the MetaHP
                agent: Agent, if not None, uses it as Learner's agent
                env: Environment, idem
                searcher: Searcher, idem
                models: list of Model, idem
                log: bool, whether or not to Log the prints or display them
                    on standard out

            Returns:
                None
        """

        self._meta = hyp.MetaHP()
        if randomize or self._meta.randomize_hp:
            self._meta.randomize()
        if log is not None:
            self._meta.log = log

        self.env = env or rle.Environment(self._meta.ep, searcher, models)
        val_ep = copy(self._meta.ep)
        val_ep.data_source = 'validation'
        self.val_env = rle.Environment(val_ep, None, self.env.models)
        self.graph = tf.Graph()

        if self._meta.prioritize:
            self.memory = ds.SumTree(capacity=self._meta.past_size)
        else:
            self.memory = ds.MemoryBuffer(max_size=self._meta.past_size)

        with self.graph.as_default():
            self.agent = agent or ag.Agent(self._meta.ap)

        if self._meta.log:
            self.print = self.print_in_log
            self.log_list = ['\n']
            self.extended_log_list = []

        else:
            self.print = print

        if self._meta.train_only_use_hops:
            def g():
                with open(self._meta.whoosh_path + 'hop_uuids.pkl', 'rb') as f:
                    hop_uuids = pkl.load(f)
                perm = permutation(len(hop_uuids['train']))
                for i in perm:
                    yield hop_uuids['train'][i]
            self.hop_uuid_gen = g()

        print('Save path : ', self._meta._save_path)
        self.print('Save path : ', self._meta._save_path)

    def __str__(self):
        """
            A learner is essentially described by its MetaHP
        """
        return str(self.meta)

    @property
    def meta(self):
        """
            If the meta HP is modified, sub-hps should be updated too

            Returns:
                MetaHP
        """
        self.agent.set_hp(self._meta.ap)
        self.env.hp = self._meta.ep
        val_ep = copy(self._meta.ep)
        val_ep.data_source = 'validation'
        self.val_env.hp = val_ep
        return self._meta


    @property
    def args(self):
        """
            Filters and sorts dir(self)

            Returns:
                list
        """
        return sorted([s for s in dir(self)
                       if '__' not in s
                       and 'args' not in s])

    @property
    def per_beta(self):
        """
            Prioritized Experience Replay Beta paramter

            Returns:
                float
        """
        if self.meta.training_step >= 0:
            shift = self.meta.training_step * (1 - self.meta.per_beta0)
            shift /= self.meta.train_episodes * self.meta.training_buffers * 0.95
            return min(self.meta.per_beta0 + shift, 1)
        return self.meta.per_beta0

    def play(self, generate=True):
        """
            Here the agent interacts with the environment.
            2 cases:
                - generate == True -> the goal is to generate a replay buffer
                - generate == False -> the goal is to evaluate the agent
            
            Args:
                generate: bool
            
            Returns:
                dict, store containing relevant values during the play phase
        """
        if generate:
            store = {
                'current_action': [],
                'current_action_wc': [],
                'current_action_submit_score': [],
                'current_action_query_score': [],
                'current_action_submit': [],
                'next_actions': [],
                'next_actions_wc': [],
                'next_actions_query_score': [],
                'next_actions_submit_score': [],
                'question': [],
                'question_wc': [],
                'reward': [],
                'not_over': [],
                'length': 0,
                'title': []
            }
        else:
            store = {
                'episode_length': [],
                'rewards': [],
                'length': 0
            }
        baseline = hasattr(self, 'baseline')
        if baseline:
            store['action_times'] = []
            store['step_times'] = []

        episodes = self.meta.train_episodes if generate else self.meta.validation_episodes
        start_time = time()
        for ep in range(episodes):
            to_print = '\r({})  Episode {:3} step {:2} transitions {:4} ({:4}s)  | Action : {: <50} (Q:{:50} | A:{:20})'
            state, start_title = self.env.reset() if generate else self.val_env.reset()
            question = self.env.question.split(' ') if generate else self.val_env.question.split(' ')
            not_over = True
            if generate:
                store['title'].append(start_title)
            timestep = 0
            ep_reward = []
            while not_over:

                actions = [act.split(' ') for act in state['texts']]
                submitable_action = [
                    _ < self.meta.submitable_actions for _ in range(len(actions))]
                scores = state['scores']
                query_scores = [
                    sc if i >= self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]
                submit_scores = [
                    sc if i < self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]

                action_time = time()
                if not baseline:
                    # RUN THROUGH AGENT
                    with self.graph.as_default():
                        action_dist = self.agent.run_action_distribution(
                            question, actions, submitable_action,
                            query_scores, submit_scores)
                else:
                    # PLAY FOR BASELINE
                    # with self.graph.as_default():
                    # action_dist = self.agent.run_action_distribution(
                    #     question, actions, submitable_action,
                    #     query_scores, submit_scores)
                    self.run_question = question
                    self.run_state = state['texts']
                    action_dist = [_ for _ in range(len(state['texts']))]
                    store['action_times'].append(time() - action_time)
                    self.print('  Get ACTION  {:.6f}s  '.format(
                        store['action_times'][-1]), end='')

                action_id = self.policy(
                    action_dist) if generate else np.argmax(action_dist)
                action_as_string = state['texts'][action_id]
                action_as_list = actions[action_id]

                step_time = time()
                step = self.env.step(action_id) if generate else self.val_env.step(action_id)
                if baseline:
                    store['step_times'].append(time() - step_time)
                    self.print('  Get STEP  {:.6f}s  '.format(store['step_times'][-1]
                                                              ), end='')
                self.step = step
                next_state, reward, not_over, title = step
                store['length'] += 1
                self.print(to_print.format(utils.ts_to_hour(time()), ep, timestep + 1,
                                           store['length'] + 1,
                                           int(time() -
                                               start_time), action_as_string,
                                           self.env.question if generate else self.val_env.question,
                                           self.env.answer if generate else self.val_env.answer)[:210],
                           end='' if ep or timestep else '\n')

                if generate:
                    current_action_query_score = state['scores'][action_id] if (
                        action_id >= self.meta.submitable_actions) else 0
                    current_action_submit_score = state['scores'][action_id] if (
                        action_id < self.meta.submitable_actions) else 0
                    next_actions_query_score = [
                        nsc if i >= self.meta.submitable_actions else 0
                        for i, nsc in enumerate(next_state['scores'])
                    ]
                    next_actions_submit_score = [
                        nsc if i < self.meta.submitable_actions else 0
                        for i, nsc in enumerate(next_state['scores'])
                    ]

                    next_state_texts = [ns.split(' ')
                                        for ns in next_state['texts']]
                    store['current_action'].append(action_as_list)
                    store['current_action_wc'].append(len(action_as_list))
                    store['current_action_query_score'].append(
                        current_action_query_score)
                    store['current_action_submit_score'].append(
                        current_action_submit_score)
                    store['current_action_submit'].append(
                        int(action_id < self.meta.submitable_actions))

                    store['next_actions'].append(next_state_texts)
                    store['next_actions_wc'].append(
                        [len(ns) for ns in next_state_texts])
                    store['next_actions_query_score'].append(
                        next_actions_query_score)
                    store['next_actions_submit_score'].append(
                        next_actions_submit_score)

                    store['question'].append(question)
                    store['question_wc'].append(len(question))

                    store['reward'].append(reward)
                    store['not_over'].append(int(not_over))
                    store['title'].append(title)
                else:
                    ep_reward.append(
                        reward)
                state = next_state
                timestep += 1
                to_print = to_print[:74]
                # END OF EPISODE
            if not generate:
                store['episode_length'].append(timestep)
                store['rewards'].append(ep_reward)
            else:
                self.meta.episode_count += 1
            # END OF BUFFER

        # END OF PLAY
        if not generate:
            store['return'] = np.array([utils.discounted_sum(ep_r, self.meta.discount)
                                        for ep_r in store['rewards']])
            store['mean_return'] = np.mean(store['return'])
            store['std_return'] = np.std(store['return'])
            return store
        # for k in store.keys():
        #     if isinstance(store[k], list):
        #         store[k] = np.array(store[k])
        # store['current_action'] = np.reshape(store['current_action'], [-1])
        # store['question'] = np.reshape(store['question'], [-1])
        # store['next_actions'] = np.reshape(
        #     store['next_actions'], [store['current_action'].shape[0], -1])

        return store

    def transition_generator(self):
        """
            Generator yielding a store containing relevant values such as current action, 
            next possible actions, reward etc. This store is the result of the Learner's 
            Agent's interaciton with the Environment.
            
            Yields:
                dict
        """

        episodes = self.meta.train_episodes * self.meta.training_buffers
        start_time = time()
        for ep in range(episodes):
            if self.meta.training_step > self.meta.total_steps:
                break
            to_print = '\r({})  Episode {:3} step {:2} ({:4}s)  | Action : {: <50} (Q:{:50} | A:{:20})'
            if self.meta.train_only_use_hops:
                uuid_gen = self.hop_uuid_gen
            else:
                uuid_gen = None
            state, _ = self.env.reset(uuid_generator=uuid_gen)
            question = self.env.question.split(' ')
            not_over = True
            timestep = 0
            while not_over:
                if self.env.is_state_terminal:
                    break
                store = {
                    'current_action': [],
                    'current_action_wc': [],
                    'current_action_submit_score': [],
                    'current_action_query_score': [],
                    'current_action_submit': [],
                    'next_actions': [],
                    'next_actions_wc': [],
                    'next_actions_query_score': [],
                    'next_actions_submit_score': [],
                    'question': [],
                    'question_wc': [],
                    'reward': [],
                    'not_over': [],
                    'length': 0,
                    'title': []
                }

                actions = [act.split(' ') for act in state['texts']]
                submitable_action = [
                    _ < self.meta.submitable_actions for _ in range(len(actions))]
                scores = state['scores']
                query_scores = [
                    sc if i >= self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]
                submit_scores = [
                    sc if i < self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]

                with self.graph.as_default():
                    action_dist = self.agent.run_action_distribution(
                        question, actions, submitable_action,
                        query_scores, submit_scores)

                action_id = self.policy(action_dist)
                action_as_string = state['texts'][action_id]
                action_as_list = actions[action_id]

                self.step = self.env.step(action_id)

                next_state, reward, not_over, title = self.step
                store['length'] += 1
                self.print(to_print.format(
                    utils.ts_to_hour(time()),
                    ep,
                    timestep,
                    int(time() - start_time),
                    action_as_string,
                    self.env.question,
                    self.env.answer),
                    end='' if bool(ep or timestep) else '\n')

                current_action_query_score = state['scores'][action_id] if (
                    action_id >= self.meta.submitable_actions) else 0
                current_action_submit_score = state['scores'][action_id] if (
                    action_id < self.meta.submitable_actions) else 0
                next_actions_query_score = [
                    nsc if i >= self.meta.submitable_actions else 0
                    for i, nsc in enumerate(next_state['scores'])
                ]
                next_actions_submit_score = [
                    nsc if i < self.meta.submitable_actions else 0
                    for i, nsc in enumerate(next_state['scores'])
                ]

                next_state_texts = [ns.split(' ')
                                    for ns in next_state['texts']]
                store['current_action'].append(action_as_list)
                store['current_action_wc'].append(len(action_as_list))
                store['current_action_query_score'].append(
                    current_action_query_score)
                store['current_action_submit_score'].append(
                    current_action_submit_score)
                store['current_action_submit'].append(
                    int(action_id < self.meta.submitable_actions))

                store['next_actions'].append(next_state_texts)
                store['next_actions_wc'].append(
                    [len(ns) for ns in next_state_texts])
                store['next_actions_query_score'].append(
                    next_actions_query_score)
                store['next_actions_submit_score'].append(
                    next_actions_submit_score)

                store['question'].append(question)
                store['question_wc'].append(len(question))

                store['reward'].append(reward)
                store['not_over'].append(int(not_over))
                store['title'].append(title)
                state = next_state
                timestep += 1
                to_print = to_print[:57]
                yield store

            self.meta.episode_count += 1
            # END OF BUFFER

    def initialize(self, matrix=None, vocab=None):
        """
            Initializes the graph and the Agent

            Args:
                matrix: 2D numpy array, embedding matrix. If None, it is 
                    loaded from the default file location defined in the 
                    MetaHP
                vocab: dict, idem

            Returns:
                None
        """
        with self.graph.as_default():
            if matrix is not None:
                self.agent.emb_matrix = matrix
            if vocab is not None:
                self.agent.emb_vocab = vocab
            self.agent.set_embedding_matrix(self.meta.embedding_file)
            self.agent.compile()
            self.agent.initialize_variables()


    @utils.keyboard_interrupt
    def train(self, copy_source=True):
        """
            Runs the appropriate training procedure depending
            on whether or not a geneartor or a buffer is expected

            Args:
                copy_source: bool, whether or not the source files as learn.py etc.
                    will be copied in the save directory to freese these files' states
            
            Returns:
                None
        """
        if self.meta.train_with_generator:
            self.train_with_generator(copy_source)
        else:
            self.train_with_buffer(copy_source)

    def train_with_buffer(self, copy_source=True):
        """
            Training Procedure for D-DQN without PER using buffers:
            the agent interacts with the Environment for a certain time, then updates
            its memory and trains on it.

            Args:
                copy_source: bool, whether or not the source files as learn.py etc.
                    will be copied in the save directory to freese these files' states
            
            Returns:
                None

        """
        start_time = time()
        self.train_start_date = utils.ts_to_date(start_time)
        self.print(self.meta.save_path, '\n')

        self.val_stores = []
        previous_store = self.play(generate=True)
        self.previous_store = previous_store
        stop_keys = {'length', 'title'}
        keys = [k for k in previous_store.keys() if k not in stop_keys]

        for buff in range(self.meta.training_buffers):
            buff_time = time()

            new_store = self.play(generate=True)
            self.new_store = new_store
            total_length = previous_store['length'] + new_store['length']
            perm = permutation(total_length)

            if self.meta.randomize_past:
                current_store = {
                    k: previous_store[k] + new_store[k]
                    for k in keys
                }
                current_store = {
                    k: [current_store[k][i] for i in perm]
                    for k in keys
                }
            else:
                current_ordered_store = {
                    k: previous_store[k] + new_store[k]
                    for k in keys
                }
                current_store = {
                    k: [current_ordered_store[k][i] for i in perm]
                    for k in keys
                }
            self.current_store = current_store
            self.print(' ')
            # for b in range(total_length // self.meta.batch_size):

            for b in range(1):
                self.print('\r({})  Buffer {:3}/{:3}  batch  {:3}/{:3} '.format(
                    utils.ts_to_hour(time()), buff +
                    1, self.meta.training_buffers, b + 1,
                    total_length // self.meta.batch_size,
                ), end='')

                batch_store = {
                    k: current_store[k][b * self.meta.batch_size:
                                        (b + 1) * self.meta.batch_size]
                    for k in keys
                }
                with self.graph.as_default():
                    if b % self.meta.update_every == 0:
                        utils.copy_networks(self.agent,
                                            self.meta.interaction_layers)

                    self.batch_store = batch_store
                    feed_dict = utils.get_train_feed_dict(
                        self.agent, batch_store)
                    self.feed_dict = feed_dict
                    merged_value, _, loss = self.agent.sess.run(
                        [self.agent.merged,
                         self.agent.opt_op,
                         self.agent.loss], feed_dict=feed_dict)
                self.print(' Loss: {:.5}  ({:.4}s)'.format(
                    loss, time() - start_time
                ), end='')
                self.agent.train_writer.add_summary(
                    merged_value, self.meta.training_step)
                self.meta.training_step += 1
                self.meta.batch_count += 1
                # END OF BATCH
                ##############
            self.print(' ')
            if buff > 0 and buff % self.meta.val_every == 0:
                self.print('\n >>>  Validation :')
                val_store = self.play(False)
                self.val_stores.append(val_store)
                self.print_val(val_store)

            self.meta.current_buffer += 1
            if self.meta.randomize_past:
                previous_store = {
                    k: current_store[k][:self.meta.past_size]
                    for k in keys
                }
            else:
                previous_store = {
                    k: current_ordered_store[k][:self.meta.past_size]
                    for k in keys
                }
            previous_store['length'] = len(previous_store['not_over'])
            self.previous_store = previous_store
            if buff > 0 and buff % self.meta.save_every == 0:
                self.save_model('buff%d' % buff)
            self.write_log_lists()
            # END OF BUFFER
            ###############
        print()
        self.final_evaluation()
        self.save_model(name='final')
        if copy_source:
            utils.copy_source_files(self.meta.save_path)

    def get_experience(self):
        """
            Extract a batch of random transitions from the replay memory

            Returns:
                None
        """
        idx, priorities, experience = self.memory.sample(self.meta.batch_size)
        sampling_probabilities = priorities / self.memory.total()
        w = np.power(self.memory.n_entries *
                     sampling_probabilities, -self.per_beta)
        w = w / w.max()
        return idx, priorities, w, experience

    def error2priority(self, errors):
        """
            Converts the errors to priorities with the PER's parameters
            alpha and a small shift epsilon to avoid 0

            Args:
                errors: list or numpy 1D array
            
            Returns:
                numpy 1D array
        """
        return np.power(np.abs(errors) + self.meta.per_epsilon, self.meta.per_alpha)

    def train_with_generator(self, copy_source=True):
        """
            Training Procedure for D-DQN with PER:
            the agent is trained on prioritized samples from
            its memory as it interacts with the environment

            Args:
                copy_source: bool, whether or not the source files as learn.py etc.
                    will be copied in the save directory to freese these files' states
            
            Returns:
                None

        """
        start_time = time()
        self.train_start_date = utils.ts_to_date(start_time)
        self.print(self.meta.save_path, '\n')

        self.val_stores = []

        self.trans_gen = self.transition_generator()
        keys = set()

        for trans_store in self.trans_gen:
            if len(keys) == 0:
                keys |= set(trans_store.keys()) - {'length', 'title'}
            self.new_store = trans_store
            if self.meta.prioritize:
                self.memory.add(
                    max(self.meta.prio_max, self.meta.per_epsilon), self.new_store)
            else:
                self.memory.add(self.new_store)

            if self.meta.training_step < 0:
                self.print('\r({}) Observing step {}'.format(
                    utils.ts_to_hour(time()),
                    self.meta.delay + self.meta.training_step
                ), end='')
                print('\r({}) Observing step {}'.format(
                    utils.ts_to_hour(time()),
                    self.meta.delay + self.meta.training_step
                ), end='')
            else:
                if self.meta.training_step == 0:
                    self.print('\n TRAINING')
                if self.meta.prioritize:
                    idx, priorities, w, experience = self.get_experience()
                    self.current_experience = experience
                    # converts list of dict to dict of lists
                    batch_store = dict(
                        [
                            (n, sum([a.get(n, []) for a in experience], []))
                            for n in keys
                        ]
                    )

                    batch_store['wis'] = w
                else:
                    batch_store = self.memory.sample(self.meta.batch_size)

                with self.graph.as_default():
                    if self.meta.training_step % self.meta.update_every == 0:
                        utils.copy_networks(self.agent,
                                            self.meta.interaction_layers)

                    self.batch_store = batch_store
                    feed_dict = utils.get_train_feed_dict(
                        self.agent, batch_store)
                    self.feed_dict = feed_dict
                    merged_value, _, self.errors, loss = self.agent.sess.run(
                        [self.agent.merged,
                            self.agent.opt_op,
                            self.agent.delta,
                            self.agent.loss], feed_dict=feed_dict)
                if self.meta.prioritize:
                    priorities = self.error2priority(self.errors)
                    self.priorities = priorities
                    for i in range(self.meta.batch_size):
                        self.memory.update(idx[i], priorities[i])
                    self.meta.prio_max = max(
                        priorities.max(), self.meta.prio_max)

                if self.meta.training_step % 250 == 0:
                    self.print('\n({}) {:20} Train step {} Loss: {:.5}  ({:.4}s)'.format(
                        utils.ts_to_hour(time()),
                        '',
                        self.meta.training_step,
                        loss,
                        time() - start_time
                    ), end='')

                self.agent.train_writer.add_summary(
                    merged_value, self.meta.training_step)

                if self.meta.training_step % self.meta.val_every_step == 0:
                    self.print(' ')
                    self.print('\n >>>  Validation :')
                    val_store = self.play(False)
                    self.val_stores.append(val_store)
                    self.print_val(val_store)

                if self.meta.training_step % self.meta.save_every_step == 0:
                    self.save_model('buff%d' % self.meta.training_step)

                if self.meta.training_step % self.meta.write_every_step == 0:
                    self.write_log_lists()

            self.meta.training_step += 1
            # END OF TRAINING
        print()
        self.final_evaluation(True)
        self.final_evaluation(False)
        self.save_model(name='final')
        if copy_source:
            utils.copy_source_files(self.meta.save_path)

    def save_model(self, name=None):
        """
            Saves the model's values, dumps the validation stores and the MetaHP

            Returns:
                None
        """
        self.meta.dump()
        self.agent.save_model(name=name)
        with open(self.meta.save_path + 'val_stores.pkl', 'wb') as f:
            pkl.dump(self.val_stores, f)
        date = [f for f in os.listdir(self.meta.save_path) if '.date' in f]
        if len(date) == 0:
            f = open(self.meta.save_path +
                     self.meta.init_date + '.date', 'w')
            f.close()
        self.print('({})  Model saved : {}'.format(
            utils.ts_to_hour(time()), self.meta.save_path + str(name) if name
            else self.meta.save_path))

    def policy(self, action_dist):
        """
            Computes the decision from the possible actions.
            Policies can be either :
                * epsilon_greedy
                * softmax
                * softmax_epsilon
                * random
                * random_submit
                * submit
            The last 3 do not imply evaluating the Agent's Q value representation,
            they are for baselines

            Args:
                action_dist: list or 1D numpy array summing to 1
                    representing the possible actions' distribution

            Returns:
                int, index of the action chosen from action_dist
        """
        if self.meta.policy == 'epsilon_greedy':
            if np.random.random() > self.meta.epsilon:
                return np.argmax(action_dist)
            else:
                action_nb = len(action_dist)
                action_dist = np.ones([action_nb]) / action_nb
                return choice([i for i in range(action_nb)],
                              p=action_dist)
        elif self.meta.policy == 'softmax':
            return choice([i for i in range(len(action_dist))],
                          p=action_dist)
        elif self.meta.policy == 'softmax_epsilon':
            if np.random.random() > self.meta.softmax_epsilon:
                return choice([i for i in range(len(action_dist))],
                              p=action_dist)
            else:
                action_nb = len(action_dist)
                action_dist = np.ones([action_nb]) / action_nb
                return choice([i for i in range(action_nb)],
                              p=action_dist)

        action_nb = len(action_dist)

        if self.meta.policy == 'random':
            action_dist = np.ones([action_nb]) / action_nb
        elif 'random_submit' in self.meta.policy:
            action_dist = np.ones([self.meta.submitable_actions]
                                  ) / (self.meta.submitable_actions)
        elif 'submit' in self.meta.policy:
            submit_action = self.meta.policy.split('_')
            submit_id = submit_action[1]
            action_id = int(submit_id)
            return action_id

        return choice([i for i in range(len(action_dist))], p=action_dist)

    def erase(self, ask=True):
        """
            Erasing a learner means deleting its save directory

            Args:
                ask: bool, wheter or not to ask if the save directory
                    should be cleaned

            Returns:
                None
        """
        _path = self.meta.save_path
        shutil.rmtree(_path)
        self.print('Erased : ', _path[:-1])
        if ask and 'y' in input('Cleaning dirs ? '):
            utils.clean_models_dir()

    def print_val(self, store):
        """
        Prints a formatted string to illustrate hte Agent's validation performance.
        It uses the custom print (self.print)

        Args:
            store: dict, play values

        Returns:
            None
        """
        partial_success = len([1 for epr in store['rewards'] for r in epr
                               if r > 0])
        s = '\n({}) Validation results:  Mean return {:.4} (std {:.4})   Mean length {:.4}'
        s += '  Partial sucesses {}/{}\n'
        self.print(s.format(
            utils.ts_to_hour(time()), store['mean_return'],
            store['std_return'],
            np.mean(store['episode_length']),
            partial_success,
            store['length']
        ))

    def print_in_log(self, *s, end='\n'):
        """
            Adds strings to the log lists

            Args: 
                *s: strings to be logged, joined on a ' '
                end: string, end of the logged strings
            
            Returns:
                None
        """
        string_to_print = ' '.join([str(ss) for ss in s]) + end
        if s[0][0] == '\r':
            if self.log_list[-1][-1] != '\n':
                self.log_list[-1] = string_to_print[1:]
            else:
                self.log_list.append(string_to_print[1:])
        else:
            if self.log_list[-1][-1] == '\n':
                self.log_list.append(string_to_print)
            else:
                self.log_list[-1] += string_to_print
        if string_to_print[-1] != '\n':
            string_to_print += '\n'
        self.extended_log_list.append(string_to_print)

    def write_log_lists(self):
        """
            Appends current log lists to the log files

            Returns:
                None
        """
        if self.meta.log:
            log_time = time()
            self.meta.log_file.writelines(self.log_list)
            self.meta.extended_log_file.writelines(self.extended_log_list)
            if not self.meta.train_with_generator:
                print('\r(%s) Write buffer %d  | Current length : %d (Training time: %s)' %
                      (utils.ts_to_hour(time()), self.meta.current_buffer,
                       self.previous_store['length'] +
                       self.new_store['length'],
                       utils.ts_to_hour(time() - self.meta.init_time)), end='')
            else:
                print('\r(%s) Write step %d  | Current length : %d (Training time: %s)' %
                      (utils.ts_to_hour(time()), self.meta.training_step,
                       self.memory.n_entries,
                       utils.ts_to_hour(time() - self.meta.init_time)), end='')
            self.log_list = ['\n']
            self.extended_log_list = ['\n']

    def final_evaluation(self, val_only_use_hops=None):
        """
            Evaluates the agent and stores every piece of information during the
            interactions.

            Args:
                val_only_use_hops: bool, wheter or not to use only 
                    instances whit hops during the evaluation

            Returns:
                - dict if in baseline mode
                - None otherwise as the dict is dumped as a pickle file
        """

        self.print(
            "\nFinal Validation for reward {}, use_only_hops : {} ".format(
                self.env.hp.reward_type,
                val_only_use_hops
            )
        )

        def val_g():
            """
                uuid generator
            """
            with open(self.meta.whoosh_path + 'hop_uuids.pkl', 'rb') as f:
                hop_uuids = pkl.load(f)
            perm = permutation(len(hop_uuids['validation']))
            for i in perm:
                yield hop_uuids['validation'][i]

        self.val_hop_uuid_gen = val_g()
        if val_only_use_hops:
            uuid_gen = self.val_hop_uuid_gen
        else:
            uuid_gen = None
        store = {
            'answers': [],
            'episode_length': [],
            'questions': [],
            'rewards': [],
            'length': 0,
            'titles': [],
            'actions_taken': [],
            'actions_taken_score': [],
            'possible_actions': [],
            'possible_actions_scores': []
        }

        episodes = self.meta.final_validation_episodes
        start_time = time()
        for ep in range(episodes):
            to_print = '\r({})  Episode {:3} step {:2} transitions {:4} ({:4}s)  | Action : {: <50} (Q:{:50} | A:{:20})'

            state, title = self.val_env.reset(uuid_generator=uuid_gen)
            question = self.val_env.question.split(' ')
            not_over = True

            store['titles'].append(title)
            store['questions'].append(self.val_env.question)
            store['answers'].append(self.val_env.answer)

            timestep = 0
            ep_reward = []
            ep_possible_actions = []
            ep_possible_actions_scores = []
            ep_action_taken = []
            ep_action_taken_score = []
            while not_over:
                ep_possible_actions.append(state['texts'])
                ep_possible_actions_scores.append(state['scores'])
                actions = [act.split(' ') for act in state['texts']]
                submitable_action = [
                    _ < self.meta.submitable_actions for _ in range(len(actions))]
                scores = state['scores']
                query_scores = [
                    sc if i >= self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]
                submit_scores = [
                    sc if i < self.meta.submitable_actions else 0
                    for i, sc in enumerate(scores)
                ]
                if not hasattr(self, 'baseline'):
                    with self.graph.as_default():
                        action_dist = self.agent.run_action_distribution(
                            question, actions, submitable_action,
                            query_scores, submit_scores)
                else:
                    action_dist = list(range(self.meta.total_action_nb))

                action_id = self.policy(action_dist)
                action_as_string = state['texts'][action_id]
                action_as_list = actions[action_id]
                ep_action_taken.append(action_as_string)
                ep_action_taken_score.append(
                    state['scores'][action_id])

                step = self.val_env.step(action_id)
                self.step = step
                next_state, reward, not_over, title = step

                ep_reward.append(reward)
                store['length'] += 1
                self.print(to_print.format(utils.ts_to_hour(time()), ep, timestep + 1,
                                           store['length'] + 1,
                                           int(time() -
                                               start_time), action_as_string,
                                           self.val_env.question,
                                           self.val_env.answer)[:210],
                           end='' if ep or timestep else '\n')

                state = next_state
                timestep += 1
                to_print = to_print[:74]
                # END OF EPISODE

            store['episode_length'].append(timestep)
            store['rewards'].append(ep_reward)
            store['actions_taken'].append(ep_action_taken)
            store['actions_taken_score'].append(ep_action_taken_score)
            store['possible_actions'].append(ep_possible_actions)
            store['possible_actions_scores'].append(ep_possible_actions_scores)
            # END OF BUFFER

        store['returns'] = np.array([utils.discounted_sum(ep_r, self.meta.discount)
                                     for ep_r in store['rewards']])
        store['mean_return'] = np.mean(store['returns'])
        store['std_return'] = np.std(store['returns'])
        self.print_val(store)
        if not hasattr(self, 'baseline'):
            if val_only_use_hops:
                with open(self.meta.save_path + 'only_use_hops_final_store.pkl', 'wb') as fs:
                    pkl.dump(store, fs)
            else:
                with open(self.meta.save_path + 'use_any_final_store.pkl', 'wb') as fs:
                    pkl.dump(store, fs)
        else:
            return store

        # END OF PLAY


if __name__ == '__main__':

    sys.setrecursionlimit(10000)
    randomize = False

    L = Learner(randomize)
    L.initialize()
    L.train()
