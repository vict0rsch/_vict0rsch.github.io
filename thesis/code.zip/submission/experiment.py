import os
import sys
import learn
import utils
import shutil
import env as rle
import numpy as np
import pickle as pkl
import tensorflow as tf
from time import time, sleep
import data_structures as ds
from importlib import reload

reload(learn)
reload(utils)
np.random.seed(2)
tf.set_random_seed(2)


class Experiment(object):

    """
        Helper class to run experiments: training models or computing baselines

        As it is simply a helper class it is not detailed
    """

    def __init__(self, path=None):
        self.learner = None
        self.learner_nb = None
        self.env = None
        self.vocab = None
        self.matrix = None
        self.run_experiment = None
        self.val_stores = None
        self.exp_path = None
        if path:
            self.load(path)
        self.reward_types = {'improve_cosine', 'instant_cosine', 'improve_score',
                             'instant_score'}
        self.policies = {'random', 'random_submit'}
        self.use_only_hops = ['use_only_hops', 'use_any']
        self.discounts = [0.5, 0.8, 1]

    def search(self, attr_tuple=None):
        self.learner_nb = 0
        self.learner = learn.Learner()
        self.learner.erase(False)
        self.env = self.learner.env
        self.matrix = self.learner.agent.emb_matrix
        self.vocab = self.learner.agent.emb_vocab
        self.run_experiment = True
        self.models_run = []

        to_search = {
            'past_size': [2000],
            'discount': self.discounts,
            'optimizer': ['RMSProp'],
            'reward_type': ['improve_score', 'improve_cosine'],
            'total_steps': [5000],
        }
        if attr_tuple:
            attr, val = attr_tuple
            to_search[attr] = [val]
        params = utils.product_of_dict_keys(to_search)

        for param_dict in params:
            try:
                print("{:50}>> Experiment {}\n{:50}params : {}".format(
                    '', self.learner_nb,
                    '', param_dict
                ))
                self.learner = learn.Learner(env=self.env)
                for p in param_dict:
                    self.learner.meta.__setattr__(p, param_dict[p])
                    if p == 'past_size':
                        if self.learner.meta.prioritize:
                            self.learner.memory = ds.SumTree(
                                capacity=param_dict[p])
                        else:
                            self.learner.memory = ds.MemoryBuffer(
                                max_size=param_dict[p])
                self.models_run.append(self.learner.meta.save_path)
                self.learner.initialize(matrix=self.matrix, vocab=self.vocab)
                sleep(5)
                self.learner.train()
                self.learner_nb += 1
            except KeyboardInterrupt:
                if 'y' in input('\nStop experiences? (%d performed)' % self.learner_nb):
                    self.run_experiment = False
                    self.dump_models()
                    if 'yes' in input('Erase last Learner (yes/no) ?'):
                        self.learner.erase()
                    else:
                        if 'y' in input('Run final Evaluation ?'):
                            self.learner.final_evaluation(True)
                            self.learner.final_evaluation(False)
                        self.learner.save_model('final')

    def run(self, exp_np=None):
        self.learner_nb = 0
        self.learner = learn.Learner()
        self.learner.erase(False)
        self.env = self.learner.env
        self.matrix = self.learner.agent.emb_matrix
        self.vocab = self.learner.agent.emb_vocab
        self.run_experiment = True
        self.models_run = []
        while self.run_experiment:
            try:
                print("{:50} >> Experiment {}".format(
                    '', self.learner_nb
                ))
                self.learner = learn.Learner(env=self.env)
                self.models_run.append(self.learner.meta.save_path)
                self.learner.initialize(matrix=self.matrix, vocab=self.vocab)
                sleep(5)
                try:
                    self.learner.train()
                except tf.errors.InvalidArgumentError as e:
                    print('<<<<<<<<<<<<< InvalidArgumentError')
                    print(e)
                    print("Batch dumped at", self.learner.meta.save_path +
                          'InvalidArgumentError_batch_store.pkl')
                    self.learner.print('<<<<<<< InvalidArgumentError',
                                       "Batch dumped at",
                                       self.learner.meta.save_path + 'InvalidArgumentError_batch_store.pkl')
                    self.learner.write_log_lists()
                    with open(self.learner.meta.save_path +
                              'InvalidArgumentError_batch_store.pkl', 'wb') as f:
                        pkl.dump(self.learner.batch_store, f)
                    self.learner_nb += 1
                    continue
                self.learner_nb += 1
                if exp_np and self.learner_nb > exp_np:
                    self.run_experiment = False
            except KeyboardInterrupt:
                if 'y' in input('\nStop experiences? (%d performed)' % self.learner_nb):
                    self.run_experiment = False
                    self.dump_models()
                    if 'yes' in input('DELETE WHOLE EXPERIMENT (yes/no) ?  '):
                        shutil.rmtree(self.exp_path)
                    if 'yes' in input('Erase last Learner (yes/no) ?'):
                        self.learner.erase()
                    else:
                        if 'y' in input('Run final Evaluation ?'):
                            self.learner.final_evaluation()
                        self.learner.save_model('final')

    def load(self, exp_path):
        with open(exp_path + 'val_stores.pkl', 'rb') as vsf:
            self.val_stores = pkl.load(vsf)
        self.exp_path = exp_path

    def baseline(self):
        try:
            self.learner = learn.Learner()
            self.learner.baseline = True
            self.learner.meta.log = True
            self.learner.meta.final_validation_episodes = 1000

            for j in range(self.learner.meta.submitable_actions):
                if j in {0, 5}:
                    self.policies.add('submit_%d' % j)

            val_stores = {
                p: {
                    rt: {
                        ds: {
                            uoh: None
                            for uoh in self.use_only_hops
                        }
                        for ds in self.discounts
                    }
                    for rt in self.reward_types
                }
                for p in self.policies
            }

            val_stores['description'] = 'For each policy, for each reward_type,'
            val_stores['description'] += ' use_only_hops or use_any instance'
            val_stores['submitable_actions'] = self.learner.meta.submitable_actions
            for p in sorted(self.policies):
                self.learner.meta.policy = p

                for rt in self.reward_types:
                    print('')
                    self.learner.val_env.hp.reward_type = rt

                    for ds in self.discounts:
                        self.learner.meta.discount = ds
                        for uoh, use in zip(self.use_only_hops[1:], [True, False][1:]):
                            self.learner.val_env.known_uuids = set()
                            self.learner.meta.val_only_use_hops = use
                            print('({}) >>> POLICY {} REWARD {} DISCOUNT {} USE_ONLY_HOPS {}'.format(
                                utils.ts_to_hour(time()), p, rt, ds, use
                            ))
                            val_stores[p][rt][ds][uoh] = self.learner.final_evaluation(
                                val_only_use_hops=use)

                            temp_print = self.learner.print
                            self.learner.print = print
                            self.learner.print_val(val_stores[p][rt][ds][uoh])
                            self.learner.print = temp_print
                            print()

        except KeyboardInterrupt:
            if 'y' in input('\nErase Learner? '):
                self.learner.erase()

        with open(self.learner.meta.save_path + 'baseline_plays.pkl', 'wb') as f:
            pkl.dump(val_stores, f)

    def print_baseline(self, baseline_path):
        L = learn.Learner()
        L.print = print
        with open(baseline_path + 'baseline_plays.pkl', 'rb') as f:
            bl_store = pkl.load(f)
        if 'submit_0' not in self.policies:
            for j in range(bl_store['submitable_actions']):
                self.policies.add('submit_%d' % j)
        print(bl_store['description'])
        for p in sorted(self.policies):
            for rt in self.reward_types:
                for uoh, use in zip(self.use_only_hops, [True, False]):
                    try:
                        print('\n >>> POLICY {} REWARD {} USE_ONLY_HOPS {}'.format(
                            p, rt, use
                        ))
                        L.print_val(bl_store[p][rt][uoh])
                    except KeyError:
                        continue
        L.erase(False)

    def dump_models(self, copy_source=True):
        dev_path = utils.get_dev_path()
        if not os.path.exists(dev_path + 'experiments/'):
            os.mkdir(dev_path + 'experiments/')
        path = dev_path + 'experiments/'
        model_dirs = [d for d in os.listdir(path) if os.path.isdir(path + d)]
        max_dir = 0
        for d in model_dirs:
            try:
                temp_dir = int(d)
                if temp_dir >= max_dir:
                    max_dir = temp_dir
            except ValueError:
                continue
        _id = str(max_dir + 1)
        path += _id + '/'
        os.mkdir(path)
        self.exp_path = path
        with open(path + 'models.txt', 'w') as f:
            for m in self.models_run:
                f.write(m + '\n')
        if copy_source:
            utils.copy_source_files(path)


if __name__ == '__main__':
    sys.setrecursionlimit(10000)

    Exp = Experiment()
    Exp.search()