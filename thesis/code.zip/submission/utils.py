import os
import re
import sys
import time
import copy
import shutil
import datetime
import numpy as np
import pickle as pkl
import tensorflow as tf
from shutil import copyfile
from itertools import product
from collections import Counter
from tensorflow.python.framework import ops
from tensorflow.contrib.layers import fully_connected

np.random.seed(2)


def selu(x):
    """
        SELU computation for a variable c

        Returns:
            Variable selu(x)
    """
    
    with ops.name_scope('elu') as scope:
        alpha = 1.6732632423543772848170429916717
        scale = 1.0507009873554804934193349852946
        return scale * tf.where(x >= 0.0, x, alpha * tf.nn.elu(x))


def load_glove(stream, vocab=None):
    """
    From jtr.io.embeddings.glove
    Loads GloVe file and merges it if optional vocabulary
    Args:
        stream (iterable): An opened filestream to the GloVe file.
        vocab (dict=None): Word2idx dict of existing vocabulary.
    Returns:
        return_vocab (Vocabulary), lookup (matrix); Vocabulary contains the
                     word2idx and the matrix contains the embedded words.
    """
    print('\rLoading GloVe vectors ..', end='')

    word2idx = {}
    first_line = stream.readline()
    dim = len(first_line.split()) - 1
    lookup = np.empty([500000, dim], dtype=np.float)
    lookup[0] = np.fromstring(first_line.split(maxsplit=1)[1], sep=' ')
    word2idx[first_line.split(maxsplit=1)[0]] = 0
    n = 1
    for line in stream:
        word, vec = line.rstrip().split(maxsplit=1)
        if vocab is None or word in vocab and word not in word2idx:
            # word = word.decode('utf-8')
            idx = len(word2idx)
            word2idx[word] = idx
            if idx > np.size(lookup, axis=0) - 1:
                lookup.resize([lookup.shape[0] + 500000, lookup.shape[1]])
            lookup[idx] = np.fromstring(vec, sep=' ')
        n += 1
    lookup.resize([len(word2idx), dim])
    # return_vocab = Vocabulary(word2idx)
    return_vocab = word2idx
    print('\rLoading GloVe vectors completed.')
    return return_vocab, lookup


def batch_dot_2D(a, b):
    """
        Args:
            a: rank 2 tensor
            b: rank 1 tensor

        Returns:
            rank 1 tensor as dot product of a and b's rows
            
    """
    with tf.variable_scope('BatchDot2D'):
        return tf.reduce_sum(tf.multiply(a, b), 1, keep_dims=True)


def batch_dot_3D(a, b):
    """
        Args:
            a: rank 3 tensor
            b: rank 2 tensor

        Returns:
            rank 2 tensor as dot product of a and b's rows
            
    """
    with tf.variable_scope('BatchDot3D'):
        return tf.reduce_sum(tf.multiply(a, b), 2, keep_dims=False)


def to_jtr_format(uuids_, questions_, answers_, answer_locations_, texts_, pad=None):
    """
        Formats lists of whoosh-generated fields into a jtr-formated dict

        *_ : lists (of same lengths) containing the values for the jrt-data attributes

        returns: a jtr-formated dict
    """
    instance_nb = len(uuids_)
    jtr_dict = {
        'instances': [-1] * instance_nb,
        'meta': {
            'source': 'utils.to_jtr_format'
        }
    }
    for i in range(instance_nb):
        text = texts_[i]
        if pad is not None:
            if len(texts_[i].split(' ')) < 6:
                tl = len(texts_[i].split(' '))
                text = ' '.join(
                    texts_[i].split(' ') + [pad] * (6 - tl)
                )

        q = questions_[i]
        if 'an instance of ?' in q:
            q = q if q[q.index('an instance of ?') -
                       1] == ' ' else q[:-16] + ' ' + q[-16:]
        instances_dict = {
            'questions': [{
                'question': {
                    'id': uuids_[i],
                    'text': q
                },
                'answers': [
                    {
                        'text': answers_[i],
                        'span': [int(np.min(answer_locations_[i])),
                                 int(np.max(answer_locations_[i]))]
                        if len(answer_locations_[i]) > 0 else []
                    }
                ]
            }],
            'support': [text]
        }
        jtr_dict['instances'][i] = instances_dict

    return jtr_dict


def free_fall(func):
    """
        decorator catching any Exception
    """
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception as e:
            print('FREE FALL : ', e)
    return wrapper


def keyboard_interrupt(func):
    """
        decorator allowing for a safe keyboard interrupt
    """
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except KeyboardInterrupt:
            if 'y' in input('Save Model?'):
                if 'y' in input('\nSpecify Name?'):
                    name = input('Name : ')
                    args[0].save_model(name)
                else:
                    args[0].save_model()
            elif 'y' in input('Erase Learner?'):
                args[0].erase()
    return wrapper


def time_(expr=None):
    """
        timing decorator
        prints the function's name if expr is None, 
        prints expr otherwise
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            start_time = time.time()
            res = func(*args, **kwargs)
            to_print = expr or func.__name__
            print('\n(@time_ : {}) {} : {:.3}s'.format(
                ts_to_hour(time.time()),
                to_print,
                time.time() - start_time
            ))
            return res
        return wrapper
    return decorator


def log(ask_save=True, keyboard_interrupt=False):
    """
        decorator redirecting sys.stdout to a log file
        and catching keyboard interrupts
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            old_stdout = sys.stdout
            path = get_dev_path() + 'rl/'
            if not os.path.exists(path + 'logs'):
                os.mkdir(path + 'logs')
            path += 'logs/'

            file_name = func.__name__ + '_' + ts_to_date(time.time())
            log_file = open(path + file_name + '.log', "w")
            sys.stdout = log_file
            if not keyboard_interrupt:
                res = func(*args, **kwargs)
                sys.stdout = old_stdout
                log_file.close()
                return res
            else:
                try:
                    res = func(*args, **kwargs)
                    return res
                except KeyboardInterrupt:
                    sys.stdout = old_stdout
                    log_file.close()
                    if ask_save and 'y' in input('Save Model?'):
                        if ask_save and 'y' in input('\nSpecify Name?'):
                            name = input('Name : ')
                            args[0].save_model(name=name)
                        else:
                            args[0].save_model()
                    elif 'y' in input('Erase Learner?'):
                        args[0].erase()
        return wrapper
    return decorator


def redirect(file_name):
    """
        decorator to log 
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            old_stdout = sys.stdout
            log_file = open(file_name, "w")
            sys.stdout = log_file
            res = func(*args, **kwargs)
            sys.stdout = old_stdout
            log_file.close()
            return res
        return wrapper
    return decorator


def get_dev_path():
    """
        returns the dev folder's location depending on whether it is run
        on a mac or ubuntu
        jtr should be ../jtr/ w.r.t. dev
    """
    if "Users" in os.listdir('/'):
        return "/Users/victor/Documents/UCL/Courses/project/code/dev/"
    else:
        return "/home/ubuntu/dev/"


def precision(prop_as_list, ans_as_list):
    """
        computes the precison of predictions prop_as_list wrt 
        ans_as_list
    """
    tp = sum([1 if w in ans_as_list else 0 for w in prop_as_list])
    return tp / len(prop_as_list)


def recall(prop_as_list, ans_as_list):
    """
        computes the recall of predictions prop_as_list wrt 
        ans_as_list
    """
    tp = sum([1 if w in ans_as_list else 0 for w in prop_as_list])
    return tp / len(ans_as_list)


def score(prop, ans):
    """
        returns the F1 score between the answer and proposal strings,
        word by word
    """
    prop_as_list = prop.split(' ')
    ans_as_list = ans.split(' ')
    prec = precision(prop_as_list, ans_as_list)
    rec = recall(prop_as_list, ans_as_list)
    return 2 * prec * rec / (rec + prec) if (rec + prec) != 0 else 0


def get_random_sub_sentence(sentence, length=3):
    """
        returns a subsentence of a given length (3 by default)

        Args:
            sentence: string to be split on white spaces and sampled from
            lenght: number of words in the sampled sub-sentence

        Returns:
            string = subsentence
    """
    sentence_as_list = sentence.split(' ')
    if len(sentence_as_list) <= length:
        return sentence
    start = np.random.randint(0, len(sentence_as_list) - length)
    return ' '.join(sentence_as_list[start:start + length])


def add_space(sentence, key):
    """
        Adds a space at the index of key if there is none

        Args:
            sentence: string, original sentence in need of an extra space
            key: string, location where there should be a space

        Returns:
            string, sentence with a space if there as none at key's index
    """
    index = sentence.index(key)
    if sentence[index - 1] != ' ':
        sentence = sentence[:index] + ' ' + sentence[index:]
    return sentence


def get_category_from_question(question):
    """
        Args:
            question: string for which we want the category

        returns:
            string, Wikireading property sought for in the reformulated
                question
    """

    question = question.lower()
    if 'an instance of ?' in question:
        return "instance of"
    elif 'sex or gender' in question:
        return 'sex or gender'
    elif 'in which country' in question:
        return 'country'
    elif ' born ?' in question:
        return "date of birth"
    elif "'s sport ?" in question:
        return 'sport'
    elif " in black and white" in question:
        return "color"
    elif "what chromosome is " in question:
        return 'chromosome'
    elif "what is the melting" in question:
        return "melting point"
    elif "which organization conferrs " in question:
        return 'conferred by'


def save_hps(env_p, agent_p, learn_p):
    """
        writes and pickles hyper parameters
    """
    ep = copy.copy(env_p)
    lp = copy.copy(learn_p)
    ap = copy.copy(agent_p)

    s = 'Hyper-parameters pickled as (env_p, agent_p, learn_p)'
    s += ':\n\n>>> Evnvironment:\n'
    s += ep.__str__()
    s += '\n>>> Agent:\n'
    s += ap.__str__()
    s += '\n>>> Learning Algorithm:\n'
    s += lp.__str__()

    with open(ep.save_path + 'hyperparameters_description.txt', 'w') as f:
        f.write(s)
    with open(ep.save_path + 'hyperparameters.pkl', 'wb') as f:
        pkl.dump((env_p, agent_p, learn_p), f)


def get_target_dict(agent, store):
    """
        returns the feed dict for the target network update

        Args:
            agent: Agent instance
            store: dict, contains the updates' values 
        returns:
            dict, as {placeholder:value} for the Action, Question
                and Interaction Networks
    """
    aw_dict = {
        agent.action_net.weights_phs[i]: store['action_net_w_%d' % i]
        for i in range(len(agent.action_net.weights_phs))
    }
    ab_dict = {
        agent.action_net.biases_phs[i]: store['action_net_b_%d' % i]
        for i in range(len(agent.action_net.biases_phs))
    }
    qw_dict = {
        agent.question_net.weights_phs[i]: store['question_net_w_%d' % i]
        for i in range(len(agent.action_net.weights_phs))
    }
    qb_dict = {
        agent.question_net.biases_phs[i]: store['question_net_b_%d' % i]
        for i in range(len(agent.question_net.biases_phs))
    }
    iw_dict = {
        agent.interaction_weights_phs[i]: store['interaction_net_w_%d' % i]
        for i in range(len(agent.interaction_weights_phs))
    }
    ib_dict = {
        agent.interaction_biases_phs[i]: store['interaction_net_b_%d' % i]
        for i in range(len(agent.interaction_biases_phs))
    }
    target_dict = {}
    for d in [aw_dict, ab_dict, qw_dict, qb_dict, iw_dict, ib_dict]:
        target_dict.update(d)
    return target_dict


def get_train_feed_dict(agent, store):
    """
        returns the train feed dict 

        Args:
            agent: Agent instance
            store: dict, contains the updates' values 
        returns:
            dict, as {placeholder:value} for a training step
    """

    current_action = agent.lookup_words_2D(store['current_action'])
    current_action_wc = store['current_action_wc']
    current_action_query_score = store['current_action_query_score']
    current_action_submit_score = store['current_action_submit_score']
    current_submit = store['current_action_submit']

    next_actions = agent.lookup_words_3D(store['next_actions'])
    next_actions_wc = np.array(list(store['next_actions_wc']))
    next_query_scores = pad_scores_2D(store['next_actions_query_score'])
    next_submit_scores = pad_scores_2D(store['next_actions_submit_score'])

    question = agent.lookup_words_2D(store['question'])
    question_wc = store['question_wc']

    reward = store['reward']
    is_not_terminal = store['not_over']

    env_dict = {
        agent.action_net.current_action_ph: np.asarray(
            current_action, dtype=int),
        agent.action_net.current_action_word_count_ph: np.asarray(
            current_action_wc, dtype=int),
        agent.action_net.next_actions_query_score_ph: next_query_scores,
        agent.action_net.next_actions_submit_score_ph: next_submit_scores,

        agent.action_net.next_actions_ph: np.asarray(
            next_actions, dtype=int),
        agent.action_net.next_actions_word_count_ph: np.asarray(
            next_actions_wc, dtype=int),
        agent.action_net.current_action_query_score_ph: current_action_query_score,
        agent.action_net.current_action_submit_score_ph: current_action_submit_score,
        agent.action_net.current_action_submit_ph: np.asarray(
            current_submit),

        agent.action_net.dropout_ph: agent.hp.dropout,

        agent.question_net.question_ph: np.asarray(
            question, dtype=int),
        agent.question_net.question_word_count_ph: np.asarray(
            question_wc, dtype=int),
        agent.question_net.dropout_ph: agent.hp.dropout,

        agent.reward_ph: np.asarray(
            reward, dtype=int),
        agent.state_is_not_terminal_ph: np.asarray(
            is_not_terminal, dtype=bool),
    }
    if agent.hp.prioritize:
        env_dict[agent.weight_is_ph] = store['wis']
    feed_dict = env_dict.copy()
    # target_dict = get_target_dict(agent, store)
    # feed_dict.update(target_dict)

    return feed_dict


def pad_scores_2D(scores):
    """
        Pads a score list of lists

        Agrs:
            scores: list of list of scores, each action's score in a batch
        
        returns:
         padded 2D numpy array
    """
    max_len = max([len(l) for l in scores])
    new_scores = np.zeros([len(scores), max_len])
    for i, l in enumerate(scores):
        new_scores[i, :len(l)] = l
    return new_scores


def ts_to_date(ts):
    """
        Human-readable timestamp format for a date
        Args:
            ts: Unix timestamp
        Returns:
            string, '%m-%d_%H:%M:%S' from ts
    """
    return datetime.datetime.fromtimestamp(ts).strftime('%m-%d_%H:%M:%S')


def ts_to_hour(ts):
    """
        Human-readable timestamp format for an time
        Args:
            ts: Unix timestamp
        Returns:
            string, 'H:%M:%S' from ts
    """
    return ts_to_date(ts)[6:]


def clean_models_dir(except_list=[]):
    """
        deletes directories of no interest:
            contains only tensorboard dir
            only log files
            nothing
        
        Args:
            except_list: list of dirs not to be deleted

        returns:
            None
    """

    dev_path = get_dev_path()
    models_path = dev_path + 'models/'
    model_list = [f for f in os.listdir(
        models_path) if os.path.isdir(models_path + f) and f not in except_list]
    to_erase = []
    print('These models will be deleted:')
    for m in model_list:
        list_dir = os.listdir(models_path + m)
        tb = list_dir == ['tensorboard']
        empty = list_dir == []
        short = len(list_dir) <= 3
        log = short
        for d in list_dir:
            log *= 'tensorboard' in d or 'log' in d

        if tb or empty or log:
            to_erase.append(models_path + m)
            print(models_path + m)
    check = input(
        'Continue (y)? Abort (default) ? Specify except dir (s)?')
    if 's' in check:
        except_dirs = input('Except dirs (d1, d2,...) : ')
        except_list += except_dirs.split(', ')
        check = 'y'
    if 'y' in check:
        for m in to_erase:
            if m not in except_list:
                shutil.rmtree(m)


def cosine(sent1, sent2):
    """
        Count-based cosine similarity

        Args:
            sent1, sent2: strings to be compared
        
        returns:
            float representing cosine(sent1, sent2)
    """
    WORD = re.compile(r'\w+')

    def get_cosine(vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])

        sum1 = sum([vec1[x]**2 for x in vec1.keys()])
        sum2 = sum([vec2[x]**2 for x in vec2.keys()])
        denominator = np.sqrt(sum1) * np.sqrt(sum2)

        if not denominator:
            return 0.0
        else:
            return float(numerator) / denominator

    def text_to_vector(text):
        words = WORD.findall(text)
        return Counter(words)

    return get_cosine(text_to_vector(sent1), text_to_vector(sent2))


def copy_source_files(new_location):
    """
        copies the Python source files to new_location

        Args:
            new_location: string, path where to copy the source files
    """
    files = ['env', 'agent', 'network', 'utils',
             'learn', 'hyperparameter', 'experiment']
    dev_path = get_dev_path()
    for f in files:
        file_path = dev_path + 'rl/' + f + '.py'
        copyfile(file_path, new_location + f + '.py')
        print('\rCopied ', f + '.py', end='')
        print(' ')


def discounted_sum(rewards, discount):
    """
        compute the return

        Args:
            rewards: list of rewards
            dsicount: float, discount factor
        returnrs:
            numpy float32 
    """
    discounts = np.power(np.ones([len(rewards)]) * discount,
                         np.arange(len(rewards)))
    return np.multiply(rewards, discounts).sum()


def fixed_linear_with_logits(input_tensor, sizes, name):
    """
        cf Agent.get_target_interaction
    """
    with tf.variable_scope(name + '_target'):
        local_tensor = input_tensor
        for i, s in enumerate(sizes[:-1]):
            local_tensor = fully_connected(
                local_tensor,
                s,
                scope='fully_connected_' + str(i),
                activation_fn=selu,
                trainable=False,
            )
        i += 1
        return fully_connected(
            local_tensor,
            sizes[i],
            activation_fn=None,
            scope='fully_connected_' + str(i),
            trainable=False
        )


def copy_networks(agent, interaction_layers):
    """
        Updates the target networks by running assign() ops in Agent.sess.run()

        Args:
            agent: Agent instance whose networs are to be updated
            interaction_layers: list of layers. only its length matters

        Returns:
            None
    """
    copy_op = []
    collection = agent.graph.get_collection('variables')
    collection = [t for t in collection
                  if 'AgentOptimizer' not in t.name]
    for inet, net in enumerate(['AN', 'QN', 'Interaction']):
        for l in ['weights', 'biases']:
            if inet < 2:
                for i in range(len(agent.hp.dense_layers)):
                    tensor = [t for t in collection if
                              net in t.name
                              and l in t.name
                              and str(i) in t.name.split(':')[0]
                              and 'target' not in t.name][0]

                    target_tensor = [t for t in collection if
                                     net in t.name
                                     and l in t.name
                                     and str(i) in t.name.split(':')[0]
                                     and 'target' in t.name][0]
                    copy_op.append(target_tensor.assign(tensor))

            else:
                for i in range(len(interaction_layers)):
                    tensor = [t for t in collection if
                              net in t.name
                              and l in t.name
                              and str(i) in t.name.split(':')[0]
                              and 'target' not in t.name][0]

                    target_tensor = [t for t in collection if
                                     net in t.name
                                     and l in t.name
                                     and str(i) in t.name.split(':')[0]
                                     and 'target' in t.name][0]
                    copy_op.append(target_tensor.assign(tensor))
    agent.sess.run(copy_op)

def product_of_dict_keys(dicts):
    """
        get cartesian product of a dict's keys and values:
            values should be lists

        returns: list of dict with each possible combination
            of dicts values with dicts's keys
    """
    return list((dict(zip(dicts, x)) for x in product(*dicts.values())))