import pickle as pkl
import os


def generate_pkl(train):
    if train:
        files = ['cyto.fasta', 'secreted.fasta', 'mito.fasta', 'nucleus.fasta']
        prefix = 'train_'
    else:
        files = ['blind.fasta']
        prefix = 'test_'

    data = []
    labels = []
    s = ''
    for fasta_file in files:
        with open(fasta_file, 'r') as f:
            lines = f.readlines()
        count = 0
        for l in lines:
            if l[0] == '>':
                if count > 0:
                    data.append(s)
                    labels.append(files.index(fasta_file))
                s = ''
            else:
                s += l[:-1]
                if count == len(lines) - 1:
                    data.append(s)
                    labels.append(files.index(fasta_file))
            count += 1
    with open(prefix + 'data.pkl', 'wb') as f:
        pkl.dump(data, f)
    with open(prefix + 'labels.pkl', 'wb') as f:
        pkl.dump(labels, f)


def get_data(train):
    if train:
        prefix = 'train_'
    else:
        prefix = 'test_'
    if not os.path.exists(prefix + 'data.pkl'):
        print('Generating data')
        generate_pkl(train)
    with open(prefix + 'data.pkl', 'rb') as f:
        data = pkl.load(f)
    with open(prefix + 'labels.pkl', 'rb') as f:
        labels = pkl.load(f)
    return data, labels
