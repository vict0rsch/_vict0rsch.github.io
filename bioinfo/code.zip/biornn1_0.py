import numpy as np
import tensorflow as tf
import os
import datetime
import time
from importlib import reload
import collections
import pickle as pkl
from sklearn.metrics import roc_auc_score
import pandas as pd
from tensorflow.contrib.tensorboard.plugins import projector


def lr_decay(learning_rate, global_step, decay_steps=1000, decay_rate=0.96):
    return tf.train.exponential_decay(learning_rate, global_step, decay_steps=1000, decay_rate=0.96)


def get_seq_len(xbatch):
    res = np.zeros(len(xbatch))
    for i, x in enumerate(xbatch):
        if min(x) == 0:
            res[i] = np.argmin(x)
        else:
            res[i] = xbatch.shape[1]
    return res


def process_cropped(cx, cy, vocab, crop_val, end_crop_val):
    embedded_cx, _ = embed(cx, vocab=vocab)
    l = len(cx)
    p = np.random.permutation(l)
    cyh = one_hot(cy)
    embedded_cx = embedded_cx[p]
    cyh = cyh[p]

    return np.concatenate((embedded_cx[:l // 2, :crop_val], embedded_cx[:l // 2, -end_crop_val:]), axis=1), cyh[:l // 2], embedded_cx[l // 2:], cyh[l // 2:]


def load_best_model():
    try:
        dir_path = './model/'
        model_dirs = [d for d in os.listdir(
            dir_path) if os.path.isdir(os.path.join(dir_path, d)) and 'task' not in d]
        best_acc = -np.inf
        print(model_dirs)
        for d in model_dirs:
            local_dir = dir_path + d
            models = [m for m in os.listdir(local_dir) if os.path.isfile(
                os.path.join(local_dir, m)) and m[-4:] == 'meta']
            for m in models:
                acc = m.split('_')[1].split('.')
                acc = float(acc[0] + '.' + acc[1])
                if acc > best_acc:
                    best_acc = acc
                    best_acc_model = dir_path + d + '/' + m[:-5]
    except FileNotFoundError:
        print('File not Found')
        best_acc_model = ''
    return best_acc_model


def get_stats(Y):
    d = collections.defaultdict(float)
    Y_num = np.argmax(Y, axis=1)
    l = len(Y)
    for y_ in Y_num:
        d[y_] += 1 / l
    return d


def get_data(train):
    if train:
        prefix = 'train_'
    else:
        prefix = 'test_'
    if not os.path.exists(prefix + 'data.pkl'):
        print('Generating data')
        # generate_pkl(train)
    with open(prefix + 'data.pkl', 'rb') as f:
        data = pkl.load(f)
    with open(prefix + 'labels.pkl', 'rb') as f:
        labels = pkl.load(f)
    return data, labels


def one_hot(Y):
    Y = np.array(Y)
    oh = np.zeros((len(Y), 4))
    oh[np.arange(len(Y)), Y] = 1.0
    return oh.astype(np.int32)


def build_embedding(input_var, emb_size):
    with tf.variable_scope("build_embedding_vars") as varscope:
        initializer = tf.contrib.layers.xavier_initializer(
            uniform=True, seed=None, dtype=tf.float32)
        embeddings = tf.get_variable(
            "Embedding_matrix", [25, emb_size], initializer=initializer, trainable=True)
        input_embedded = tf.nn.embedding_lookup(embeddings, input_var)
    return input_embedded, embeddings


def build_mlp(input_var, sizes, train):

    var = input_var
    for i, s in enumerate(sizes):
        scope_name = 'MLP_layer_vars' + str(i)
        with tf.variable_scope(scope_name) as scope:
            lin = tf.contrib.layers.linear(var, s, scope=scope_name)
            relu = tf.nn.relu(lin)
            var = batch_norm_wrapper(relu, train)
    return var


def save(session, dev_accuracy, epoch, new_dir):
    saver = tf.train.Saver(write_version=tf.train.SaverDef.V1)

    saver.save(session, new_dir + 'epoch' + str(epoch) + '_' +
               str(int(dev_accuracy * 100000) / 1000) + '.checkpoint')


def build_rnn(dropout, sizes):
    cells = []
    with tf.variable_scope('build_rnn_vars') as scope:
        for layer_size in sizes:
            gru_cell = tf.contrib.rnn.GRUCell(layer_size)
            gru_cell = tf.contrib.rnn.DropoutWrapper(
                gru_cell, input_keep_prob=dropout)
            cells.append(gru_cell)
        cell = tf.contrib.rnn.MultiRNNCell(cells, state_is_tuple=True)
    return cell


def embed(X_data, vocab=None, ext_len=None, return_data=True):
    new_X = []
    ext_vocab = True
    if vocab is None:
        vocab = {'<PAD>': 0, '<OOV>': 1}
        ext_vocab = False

    max_len = 0
    sequence_L = []
    if return_data:
        for x in X_data:
            embedded = []
            for s in x:
                if not ext_vocab:
                    if s in vocab:
                        embedded.append(vocab[s])
                    else:
                        vocab[s] = len(vocab)
                        embedded.append(vocab[s])
                else:
                    if s in vocab:
                        embedded.append(vocab[s])
                    else:
                        embedded.append(vocab['<OOV>'])
            if len(embedded) > max_len:
                max_len = len(embedded)
            new_X.append(embedded)
            sequence_L.append(len(embedded))

        if ext_len is not None:
            max_len = ext_len
        out_x = np.full([len(X_data), max_len], vocab['<PAD>'], dtype=np.int32)

        for i, emb in enumerate(new_X):
            out_x[i, :len(emb)] = emb

        return out_x, np.array(sequence_L), vocab
    else:
        for x in X_data:
            embedded = []
            for s in x:
                if not ext_vocab:
                    if s in vocab:
                        embedded.append(vocab[s])
                    else:
                        vocab[s] = len(vocab)
                        embedded.append(vocab[s])
                else:
                    if s in vocab:
                        embedded.append(vocab[s])
                    else:
                        embedded.append(vocab['<OOV>'])
            if len(embedded) > max_len:
                max_len = len(embedded)
            sequence_L.append(len(embedded))

        return 0, np.array(sequence_L), vocab


def crop_train_data(X_data, Y_data, val, end_val):
    new_X = []
    new_y = []
    cropped_X = []
    cropped_y = []
    for i, x in enumerate(X_data):
        if len(x) <= val + end_val:
            new_X.append(x)
            new_y.append(Y_data[i])
        else:
            cropped_X.append(x)
            cropped_y.append(Y_data[i])
    return new_X, new_y, cropped_X, cropped_y


def confusion_matrix(confusion_true, confusion_pred):
    true_values = pd.Series(confusion_true, name='Actual')
    predicted_values = pd.Series(confusion_pred, name='Predicted')
    df_confusion = pd.crosstab(true_values, predicted_values)
    print("Confusion matrix:")
    print(df_confusion)


def get_class_loss(var, y):
    with tf.variable_scope('class_loss') as scope:
        logts = tf.contrib.layers.linear(var, 4)
        class_loss = tf.nn.softmax_cross_entropy_with_logits(
            logits=logts, labels=y)
        class_loss = tf.reduce_mean(class_loss)
        tf.summary.scalar('Classification_loss', class_loss)
        prediction = tf.nn.softmax(logts)
    return prediction, class_loss


def optimize(loss, lr):
    optimizer = tf.train.AdamOptimizer(lr).minimize(loss)
    return optimizer


def batch_norm_wrapper(inputs, is_training, decay=0.999):
    with tf.variable_scope('batch_norm_wrapper_vars') as scope:
        epsilon = 1e-3
        scale = tf.Variable(tf.ones([inputs.get_shape()[-1]]))
        beta = tf.Variable(tf.zeros([inputs.get_shape()[-1]]))
        pop_mean = tf.Variable(
            tf.zeros([inputs.get_shape()[-1]]), trainable=False)
        pop_var = tf.Variable(
            tf.ones([inputs.get_shape()[-1]]), trainable=False)

        if is_training:
            batch_mean, batch_var = tf.nn.moments(inputs, [0])
            train_mean = tf.assign(pop_mean,
                                   pop_mean * decay + batch_mean * (1 - decay))
            train_var = tf.assign(pop_var,
                                  pop_var * decay + batch_var * (1 - decay))
            with tf.control_dependencies([train_mean, train_var]):
                return tf.nn.batch_normalization(inputs,
                                                 batch_mean, batch_var, beta, scale, epsilon)
        else:
            return tf.nn.batch_normalization(inputs,
                                             pop_mean, pop_var, beta, scale, epsilon)


def compute_accuracy_by_batch(variables, X_data, Y_data, L_data, accuracy, sess, y_final_with_softmax, merged=None, writer=None):
    acc = []
    predictions = []
    X_ = variables['X']
    sq_len = variables['seq_len']
    keep_prob_drop = variables['keep_prob_dropout']
    y_ = variables['y']
    batch_size = len(X_data) if len(X_data) < 50 else 50

    for i in range(len(X_data) // batch_size):
        x_batch, l_batch, _ = embed(
            X_data[i * batch_size: (i + 1) * batch_size].tolist(), vocab=vocab)
        y_batch = Y_data[i * batch_size: (i + 1) * batch_size]
        feed_dict = {
            X_: x_batch,
            y_: y_batch,
            sq_len: l_batch,
            keep_prob_drop: 1
        }
        if writer is None:
            current_acc, prediction = sess.run(
                [accuracy, y_final_with_softmax], feed_dict=feed_dict)
        else:
            merged_value, current_acc, prediction = sess.run(
                [merged, accuracy, y_final_with_softmax], feed_dict=feed_dict)
            writer.add_summary(merged_value)
        acc.append(current_acc)
        predictions.append(prediction)
    return sum(acc) / (len(X_data) // batch_size), np.array([p for pred in predictions for p in pred])


if __name__ == '__main__':
    # Parameters
    continuing = False
    train = True
    crop_sequence_value = -1
    end_crop_sequence_value = 1
    validation_size = 0
    epochs = 25
    batch_size = 32
    learning_rate = 0.005
    embedding_dim = 40
    vocab_size = 0
    bidirectional = True
    rnn_sizes = [128, 128]
    mlp_sizes = [128, 128]
    model_to_restore = ''
    save_model = True
    small_dataset = -1
    # --- --- --- --- --- --- --- --- --- --- --- ---

    # 0 -> 3004 | 1 -> 1605 | 2 -> 1299 | 3 -> 3314
    X, Y = get_data(True)
    Y = one_hot(np.array(Y))
    X_test, Y_test = get_data(False)
    _, L, vocab = embed(X, return_data=False)
    X_not_embedded = np.array(X)
    perm = np.random.permutation(len(X_not_embedded))

    X_not_embedded = X_not_embedded[perm]
    Y = Y[perm]
    L = L[perm]

    X_train = X_not_embedded[validation_size:]
    Y_train = Y[validation_size:]
    L_train = L[validation_size:]


    print('Training stats : ', *[t[1] * 100 //
                                 1 for t in get_stats(Y_train).items()])
    print('Validation stats : ', *[t[1] * 100 //
                                   1 for t in get_stats(Y_val).items()])

    n = len(X_train)

    tf.reset_default_graph()

    keep_prob_dropout = tf.placeholder(tf.float32, name='dropout')
    X = tf.placeholder(tf.int32, [None, None], "input_tensor")
    seq_len = tf.placeholder(tf.int32, [None], 'sequence_length_tensor')
    y = tf.placeholder(tf.int32, [None, 4], name='target')
    global_step = tf.Variable(0, name='global_step_tensor')

    variables = {
        'seq_len': seq_len,
        'keep_prob_dropout': keep_prob_dropout,
        'X': X,
        'y': y
    }

    X_embedded, embedding_matrix_var = build_embedding(X, embedding_dim)

    multi_rnn = build_rnn(keep_prob_dropout, rnn_sizes)

    if not bidirectional:
        with tf.variable_scope('dynamic_rnn_vars') as scope:
            output, states = tf.nn.dynamic_rnn(
                multi_rnn, X_embedded, sequence_length=seq_len, dtype=tf.float32)
        to_be_normed = states[-1]
    else:
        with tf.variable_scope('bidirectional_dynamic_rnn_vars') as scope:
            outputs, states = tf.nn.bidirectional_dynamic_rnn(
                multi_rnn, multi_rnn, X_embedded, sequence_length=seq_len, dtype=tf.float32)
            output_fw, output_bw = outputs
            states_fw, states_bw = states
        to_be_normed = tf.concat([states_fw[-1], states_bw[-1]], axis=1)

    norm_output = batch_norm_wrapper(to_be_normed, train)
    logits = build_mlp(norm_output, mlp_sizes, train)

    y_final_with_softmax, loss = get_class_loss(logits, y)
    with tf.variable_scope('correct_prediction_var') as scope:
        correct_prediction = tf.equal(
            tf.argmax(y_final_with_softmax, 1), tf.argmax(y, 1))
    with tf.variable_scope('accuracy_var') as scope:
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    tf.summary.scalar('Accuracy', accuracy)

    with tf.variable_scope('optimize_loss_vars') as scope:
        opt_op = tf.contrib.layers.optimize_loss(loss, global_step, learning_rate, 'Adam', gradient_noise_scale=None, gradient_multipliers=None, clip_gradients=2.0,
                                                 learning_rate_decay_fn=lr_decay, update_ops=None, variables=None, name=None,
                                                 summaries=["learning_rate", "loss", "gradients", "gradient_norm"], colocate_gradients_with_ops=False)

    if train:
        try:
            sess = tf.Session()

            dir_path = './model_final_bio'
            if not os.path.exists(dir_path):
                os.mkdir(dir_path)

            existing_dirs = len([d for d in os.listdir(
                dir_path) if os.path.isdir(os.path.join(dir_path, d))])
            save_dir = dir_path + '/' + str(existing_dirs)
            if not os.path.exists(save_dir):
                os.mkdir(save_dir)
            save_dir += '/'

            writer_id = datetime.datetime.fromtimestamp(
                time.time()).strftime('%m-%d_%H:%M:%S')

            train_loss_writer = tf.summary.FileWriter(
                './tensorboard/model_final_bio/' + writer_id + '/train/', sess.graph)
            test_acc_writer = tf.summary.FileWriter(
                './tensorboard/model_final_bio/' + writer_id + '/test/', sess.graph)

            # TENSORBOARD EMBEDDING
            embedding_writer = tf.summary.FileWriter(save_dir, sess.graph)
            config = projector.ProjectorConfig()
            embedding = config.embeddings.add()
            embedding.tensor_name = embedding_matrix_var.name
            embedding.metadata_path = os.path.join('./metadata.tsv')
            projector.visualize_embeddings(embedding_writer, config)

            merged = tf.summary.merge_all()

            sess.run(tf.global_variables_initializer())
            start_time = time.time()
            best_test_acc = -np.inf
            batch_times = []
            for ep in range(epochs):
                print('Epoch #  ', ep)
                epoch_time = time.time()
                perm = np.random.permutation(X_train.shape[0])
                X_train = X_train[perm]
                Y_train = Y_train[perm]
                total_loss = 0
                for i in range(n // batch_size):
                    batch_time = time.time()
                    batch_times = batch_times[-200:]
                    x_batch, l_batch, _ = embed(
                        X_train[i * batch_size: (i + 1) * batch_size].tolist(), vocab=vocab)
                    y_batch = Y_train[i * batch_size: (i + 1) * batch_size]
                    feed_dict = {
                        X: x_batch,
                        y: y_batch,
                        seq_len: l_batch,
                        keep_prob_dropout: .9
                    }
                    merged_value, _, current_loss = sess.run(
                        [merged, opt_op, loss], feed_dict=feed_dict)

                    step = (n // batch_size) * ep + i
                    train_loss_writer.add_summary(merged_value, step)

                    total_loss += current_loss
                    batch_times.append(time.time() - batch_time)
                    time_per_epoch = np.mean(
                        batch_times) * (n // batch_size)
                    remaining_time = time_per_epoch - time.time() + epoch_time

                    print('\rEnd of batch ', i, '  Train loss: %.6f | %ds left for epoch (%.2f m/ep)' % (
                        total_loss / (i + 1), remaining_time, time_per_epoch / 60), end='')


                print('\rTrain loss: %.6f' % (total_loss / n), end='')

                train_acc, _ = compute_accuracy_by_batch(
                    variables, X_train, Y_train, L_train, accuracy, sess, y_final_with_softmax, merged)

                print('   Train Accuracy : %.5f' %
                      train_acc)
                if save_model:
                    save(sess, train_acc, ep, save_dir)

                
        except KeyboardInterrupt:
            if 'y' in input('\n\ntest?'):
                train = False
                continuing = True
            else:
                sess.close()

    if not train:
        saver2restore = tf.train.Saver()
        if not continuing:
            sess = tf.Session()
            if 'y' in input('Current model is %s -- Change to best model?' % model_to_restore):
                model_to_restore = load_best_model()
            saver2restore.restore(sess, model_to_restore)

        print('Y_train distribution : ', Y_train.sum(
            axis=0), '(total : %d)' % len(Y_train))
        print('Y_val distribution (< %d long): ' % crop_sequence_value,
              Y_val.sum(axis=0), '(total : %d)' % len(Y_val))
        print('Y_val_long distribution : ', Y_long_test.sum(
            axis=0), '(total : %d)' % len(Y_long_test))
        print('\nStats on cropped data:')
        val_acc, predictions = compute_accuracy_by_batch(variables,
                                                         X_val, Y_val, L_val, accuracy, sess, y_final_with_softmax)
        print("Validation Accuracy %.5f" % val_acc)
        lim = min(len(Y_val), len(predictions))
        print("AUC score", roc_auc_score(Y_val[:lim], predictions[:lim]))
        confusion_matrix(np.argmax(Y_val[:lim], axis=1), np.argmax(
            predictions[:lim], axis=1))

        if 'y' not in input('Keep session open?'):
            sess.close()
